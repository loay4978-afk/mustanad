#!/usr/bin/env bash
# يُشغَّل بعد `flutter create .` لتهيئة أندرويد وiOS (صلاحيات الكاميرا واسم التطبيق)
set -e
MANIFEST=android/app/src/main/AndroidManifest.xml

if ! grep -q "android.permission.CAMERA" "$MANIFEST"; then
  sed -i '0,/<application/s#<application#<uses-permission android:name="android.permission.CAMERA"/>\n    <uses-feature android:name="android.hardware.camera" android:required="false"/>\n    <application#' "$MANIFEST"
fi
sed -i 's#android:label="[^"]*"#android:label="Mustanad"#' "$MANIFEST"

if [ -f ios/Runner/Info.plist ]; then
python3 - <<'PY'
p='ios/Runner/Info.plist'
s=open(p,encoding='utf-8').read()
add=''
if 'NSCameraUsageDescription' not in s:
    add+='\t<key>NSCameraUsageDescription</key>\n\t<string>Camera is used to scan documents.</string>\n'
if 'NSPhotoLibraryUsageDescription' not in s:
    add+='\t<key>NSPhotoLibraryUsageDescription</key>\n\t<string>Photos are imported and converted to documents.</string>\n'
if add:
    i=s.rfind('</dict>')
    s=s[:i]+add+s[i:]
    open(p,'w',encoding='utf-8').write(s)
PY
fi
echo "ci_setup done"
