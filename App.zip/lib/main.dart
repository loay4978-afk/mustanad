import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:get/get.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'app/bindings.dart';
import 'app/controllers/app_controller.dart';
import 'app/data/db/app_db.dart';
import 'app/theme/app_theme.dart';
import 'app/translations/app_translations.dart';
import 'app/views/home_view.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting();
  await AppDb.instance.database;
  final app = Get.put(AppController(), permanent: true);
  await app.load();
  runApp(const MustanadApp());
}

class MustanadApp extends StatelessWidget {
  const MustanadApp({super.key});

  @override
  Widget build(BuildContext context) {
    final app = Get.find<AppController>();
    return GetMaterialApp(
      title: 'Mustanad',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: app.themeMode.value,
      translations: AppTranslations(),
      locale: Locale(app.lang.value),
      fallbackLocale: const Locale('en'),
      supportedLocales: const [Locale('ar'), Locale('en'), Locale('de')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      initialBinding: InitialBinding(),
      home: const HomeView(),
    );
  }
}
