// محرك المسح: اكتشاف الحواف، تصحيح المنظور، إزالة الظلال، فلاتر التحسين.
// كل الدوال هنا Dart خالص (بدون Flutter) لتعمل داخل Isolate بدون تجميد الواجهة.
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:image/image.dart' as img;

class Pt {
  final double x, y;
  const Pt(this.x, this.y);
}

class RgbImage {
  final int width, height;
  final Uint8List data; // RGB RGB RGB ...
  RgbImage(this.width, this.height, this.data);
}

class GrayImage {
  final int width, height;
  final Uint8List data;
  GrayImage(this.width, this.height, this.data);
}

const int kFilterOriginal = 0;
const int kFilterAuto = 1;
const int kFilterMagic = 2;
const int kFilterBW = 3;
const int kFilterGray = 4;
const int kFilterCount = 5;

int _clamp255(num v) => v < 0 ? 0 : (v > 255 ? 255 : v.toInt());

// ───────────────────────── فك/ترميز الصور ─────────────────────────

RgbImage decodeToRgb(Uint8List bytes, {int maxSide = 3200}) {
  var im = img.decodeImage(bytes);
  if (im == null) throw Exception('decode failed');
  im = img.bakeOrientation(im);
  final longSide = math.max(im.width, im.height);
  if (longSide > maxSide) {
    final s = maxSide / longSide;
    im = img.copyResize(
      im,
      width: math.max(1, (im.width * s).round()),
      height: math.max(1, (im.height * s).round()),
      interpolation: img.Interpolation.average,
    );
  }
  final w = im.width, h = im.height;
  final out = Uint8List(w * h * 3);
  var i = 0;
  final ch = im.numChannels;
  if (im.format == img.Format.uint8) {
    if (ch == 1) {
      for (final p in im) {
        final v = p.r.toInt();
        out[i++] = v;
        out[i++] = v;
        out[i++] = v;
      }
    } else {
      for (final p in im) {
        out[i++] = p.r.toInt();
        out[i++] = p.g.toInt();
        out[i++] = p.b.toInt();
      }
    }
  } else {
    for (final p in im) {
      out[i++] = (p.rNormalized * 255).round();
      out[i++] = (ch == 1 ? p.rNormalized : p.gNormalized) * 255 ~/ 1;
      out[i++] = (ch == 1 ? p.rNormalized : p.bNormalized) * 255 ~/ 1;
    }
  }
  return RgbImage(w, h, out);
}

Uint8List encodeJpegRgb(RgbImage im, {int quality = 90}) {
  final image = img.Image.fromBytes(
    width: im.width,
    height: im.height,
    bytes: im.data.buffer,
    numChannels: 3,
  );
  return img.encodeJpg(image, quality: quality);
}

GrayImage rgbToGraySmall(RgbImage im, int maxSide) {
  final step = math.max(1, (math.max(im.width, im.height) / maxSide).ceil());
  final tw = im.width ~/ step, th = im.height ~/ step;
  final out = Uint8List(tw * th);
  final d = im.data;
  for (var y = 0; y < th; y++) {
    for (var x = 0; x < tw; x++) {
      var sum = 0;
      for (var yy = 0; yy < step; yy++) {
        final row = (y * step + yy) * im.width;
        for (var xx = 0; xx < step; xx++) {
          final k = (row + x * step + xx) * 3;
          sum += (d[k] * 77 + d[k + 1] * 150 + d[k + 2] * 29) >> 8;
        }
      }
      out[y * tw + x] = sum ~/ (step * step);
    }
  }
  return GrayImage(tw, th, out);
}

// ───────────────────────── مرشحات أساسية ─────────────────────────

Uint8List _boxBlurC(Uint8List src, int w, int h, int ch, int r) {
  if (r <= 0) return src;
  final tmp = Uint8List(src.length);
  final out = Uint8List(src.length);
  final win = 2 * r + 1;
  for (var y = 0; y < h; y++) {
    final row = y * w;
    for (var c = 0; c < ch; c++) {
      var sum = 0;
      for (var k = -r; k <= r; k++) {
        final xx = k < 0 ? 0 : (k >= w ? w - 1 : k);
        sum += src[(row + xx) * ch + c];
      }
      for (var x = 0; x < w; x++) {
        tmp[(row + x) * ch + c] = sum ~/ win;
        final add = x + r + 1 >= w ? w - 1 : x + r + 1;
        final rem = x - r < 0 ? 0 : x - r;
        sum += src[(row + add) * ch + c] - src[(row + rem) * ch + c];
      }
    }
  }
  for (var x = 0; x < w; x++) {
    for (var c = 0; c < ch; c++) {
      var sum = 0;
      for (var k = -r; k <= r; k++) {
        final yy = k < 0 ? 0 : (k >= h ? h - 1 : k);
        sum += tmp[(yy * w + x) * ch + c];
      }
      for (var y = 0; y < h; y++) {
        out[(y * w + x) * ch + c] = sum ~/ win;
        final add = y + r + 1 >= h ? h - 1 : y + r + 1;
        final rem = y - r < 0 ? 0 : y - r;
        sum += tmp[(add * w + x) * ch + c] - tmp[(rem * w + x) * ch + c];
      }
    }
  }
  return out;
}

int _otsu(Uint8List g) {
  final hist = List<int>.filled(256, 0);
  for (final v in g) {
    hist[v]++;
  }
  final total = g.length;
  double sum = 0;
  for (var i = 0; i < 256; i++) {
    sum += i * hist[i];
  }
  double sumB = 0, maxVar = -1;
  var wB = 0, thr = 128;
  for (var t = 0; t < 256; t++) {
    wB += hist[t];
    if (wB == 0) continue;
    final wF = total - wB;
    if (wF == 0) break;
    sumB += t * hist[t];
    final mB = sumB / wB, mF = (sum - sumB) / wF;
    final v = wB.toDouble() * wF * (mB - mF) * (mB - mF);
    if (v > maxVar) {
      maxVar = v;
      thr = t;
    }
  }
  return thr;
}

// ───────────────────────── اكتشاف حواف المستند ─────────────────────────

class _Comp {
  int area = 0;
  final List<int> boundary = [];
}

List<_Comp> _components(Uint8List mask, int w, int h, int minArea) {
  final visited = Uint8List(w * h);
  final stack = Int32List(w * h);
  final comps = <_Comp>[];
  for (var s = 0; s < w * h; s++) {
    if (mask[s] == 0 || visited[s] == 1) continue;
    var sp = 0;
    stack[sp++] = s;
    visited[s] = 1;
    final c = _Comp();
    while (sp > 0) {
      final p = stack[--sp];
      c.area++;
      final x = p % w, y = p ~/ w;
      var edge = false;
      if (x > 0) {
        final q = p - 1;
        if (mask[q] == 1) {
          if (visited[q] == 0) {
            visited[q] = 1;
            stack[sp++] = q;
          }
        } else {
          edge = true;
        }
      } else {
        edge = true;
      }
      if (x < w - 1) {
        final q = p + 1;
        if (mask[q] == 1) {
          if (visited[q] == 0) {
            visited[q] = 1;
            stack[sp++] = q;
          }
        } else {
          edge = true;
        }
      } else {
        edge = true;
      }
      if (y > 0) {
        final q = p - w;
        if (mask[q] == 1) {
          if (visited[q] == 0) {
            visited[q] = 1;
            stack[sp++] = q;
          }
        } else {
          edge = true;
        }
      } else {
        edge = true;
      }
      if (y < h - 1) {
        final q = p + w;
        if (mask[q] == 1) {
          if (visited[q] == 0) {
            visited[q] = 1;
            stack[sp++] = q;
          }
        } else {
          edge = true;
        }
      } else {
        edge = true;
      }
      if (edge) c.boundary.add(p);
    }
    if (c.area >= minArea) comps.add(c);
  }
  comps.sort((a, b) => b.area.compareTo(a.area));
  return comps;
}

double _cross(Pt o, Pt a, Pt b) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);

List<Pt> _convexHull(List<Pt> pts) {
  pts.sort((a, b) => a.x != b.x ? a.x.compareTo(b.x) : a.y.compareTo(b.y));
  final lower = <Pt>[];
  for (final p in pts) {
    while (lower.length >= 2 && _cross(lower[lower.length - 2], lower.last, p) <= 0) {
      lower.removeLast();
    }
    lower.add(p);
  }
  final upper = <Pt>[];
  for (final p in pts.reversed) {
    while (upper.length >= 2 && _cross(upper[upper.length - 2], upper.last, p) <= 0) {
      upper.removeLast();
    }
    upper.add(p);
  }
  lower.removeLast();
  upper.removeLast();
  return [...lower, ...upper];
}

double _polyArea(List<Pt> p) {
  var s = 0.0;
  for (var i = 0; i < p.length; i++) {
    final a = p[i], b = p[(i + 1) % p.length];
    s += a.x * b.y - b.x * a.y;
  }
  return s / 2;
}

/// أفضل رباعي داخل الغلاف المحدّب: أبعد زوج نقاط كقطر + أبعد نقطة على كل جانب
List<Pt>? _quadFromHull(List<Pt> hull) {
  final n = hull.length;
  if (n < 4) return null;
  var bi = 0, bj = 1;
  var bd = -1.0;
  for (var i = 0; i < n; i++) {
    for (var j = i + 1; j < n; j++) {
      final dx = hull[i].x - hull[j].x, dy = hull[i].y - hull[j].y;
      final d = dx * dx + dy * dy;
      if (d > bd) {
        bd = d;
        bi = i;
        bj = j;
      }
    }
  }
  final a = hull[bi], b = hull[bj];
  Pt? c1, c2;
  var m1 = 0.0, m2 = 0.0;
  for (final p in hull) {
    final cr = _cross(a, b, p);
    if (cr > m1) {
      m1 = cr;
      c1 = p;
    }
    if (cr < m2) {
      m2 = cr;
      c2 = p;
    }
  }
  if (c1 == null || c2 == null) return null;
  var quad = [a, c1, b, c2];
  if (_polyArea(quad) < 0) quad = quad.reversed.toList();
  // نبدأ من الزاوية العليا اليسرى (أصغر x+y) والترتيب مع عقارب الساعة
  var start = 0;
  var best = double.infinity;
  for (var i = 0; i < 4; i++) {
    final s = quad[i].x + quad[i].y;
    if (s < best) {
      best = s;
      start = i;
    }
  }
  return [for (var i = 0; i < 4; i++) quad[(start + i) % 4]];
}

class QuadResult {
  final List<Pt> corners; // طبيعية 0..1 : TL, TR, BR, BL
  final double score;
  QuadResult(this.corners, this.score);
}

QuadResult? detectQuad(GrayImage g) {
  final w = g.width, h = g.height;
  if (w < 16 || h < 16) return null;
  var gray = _boxBlurC(g.data, w, h, 1, 2);
  gray = _boxBlurC(gray, w, h, 1, 2);
  final t = _otsu(gray);
  final total = w * h;
  QuadResult? best;

  for (final bright in [true, false]) {
    final mask = Uint8List(total);
    for (var i = 0; i < total; i++) {
      mask[i] = (bright ? gray[i] > t : gray[i] <= t) ? 1 : 0;
    }
    final comps = _components(mask, w, h, (total * 0.08).round());
    for (final c in comps.take(3)) {
      if (c.area > total * 0.97) continue;
      final pts = [for (final p in c.boundary) Pt((p % w) + 0.5, (p ~/ w) + 0.5)];
      if (pts.length < 8) continue;
      final hull = _convexHull(pts);
      final hullArea = _polyArea(hull).abs();
      if (hullArea <= 0) continue;
      final solidity = c.area / hullArea;
      if (solidity < 0.55) continue;
      final quad = _quadFromHull(hull);
      if (quad == null) continue;
      final qa = _polyArea(quad).abs();
      if (qa <= 0) continue;
      final fit = math.min(1.0, hullArea / qa);
      final areaFrac = qa / total;
      if (fit < 0.82 || areaFrac < 0.10 || areaFrac > 0.985) continue;
      var score = fit * 0.5 + math.min(1.0, areaFrac * 1.4) * 0.5;
      final nearBorder = quad.every((p) =>
          p.x < w * 0.02 || p.x > w * 0.98 || p.y < h * 0.02 || p.y > h * 0.98);
      if (nearBorder) score *= 0.3;
      if (best == null || score > best.score) {
        best = QuadResult([for (final p in quad) Pt(p.x / w, p.y / h)], score);
      }
    }
  }
  if (best != null && best.score < 0.45) return null;
  return best;
}

List<Pt> defaultCorners() => const [Pt(0.03, 0.03), Pt(0.97, 0.03), Pt(0.97, 0.97), Pt(0.03, 0.97)];

// ───────────────────────── تصحيح المنظور ─────────────────────────

List<double> _homography(double w, double h, List<Pt> q) {
  // يحوّل (x,y) في الصورة الناتجة إلى (u,v) في المصدر
  final dst = [const Pt(0, 0), Pt(w, 0), Pt(w, h), Pt(0, h)];
  final a = List.generate(8, (_) => List<double>.filled(9, 0));
  for (var i = 0; i < 4; i++) {
    final x = dst[i].x, y = dst[i].y, u = q[i].x, v = q[i].y;
    a[2 * i] = [x, y, 1, 0, 0, 0, -x * u, -y * u, u];
    a[2 * i + 1] = [0, 0, 0, x, y, 1, -x * v, -y * v, v];
  }
  for (var c = 0; c < 8; c++) {
    var piv = c;
    for (var r = c + 1; r < 8; r++) {
      if (a[r][c].abs() > a[piv][c].abs()) piv = r;
    }
    final tmp = a[c];
    a[c] = a[piv];
    a[piv] = tmp;
    final d = a[c][c];
    if (d.abs() < 1e-12) continue;
    for (var k = c; k < 9; k++) {
      a[c][k] /= d;
    }
    for (var r = 0; r < 8; r++) {
      if (r == c) continue;
      final f = a[r][c];
      if (f == 0) continue;
      for (var k = c; k < 9; k++) {
        a[r][k] -= f * a[c][k];
      }
    }
  }
  return [for (var i = 0; i < 8; i++) a[i][8]];
}

RgbImage warpQuad(RgbImage src, List<Pt> q, {int maxSide = 2600}) {
  double dist(Pt a, Pt b) => math.sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
  var outW = math.max(dist(q[0], q[1]), dist(q[3], q[2]));
  var outH = math.max(dist(q[0], q[3]), dist(q[1], q[2]));
  final long = math.max(outW, outH);
  if (long > maxSide) {
    final s = maxSide / long;
    outW *= s;
    outH *= s;
  }
  final W = math.max(16, outW.round()), H = math.max(16, outH.round());
  final hm = _homography(W.toDouble(), H.toDouble(), q);
  final out = Uint8List(W * H * 3);
  final sw = src.width, sh = src.height, sd = src.data;
  var o = 0;
  for (var y = 0; y < H; y++) {
    final yy = y + 0.5;
    for (var x = 0; x < W; x++) {
      final xx = x + 0.5;
      final den = hm[6] * xx + hm[7] * yy + 1.0;
      var u = (hm[0] * xx + hm[1] * yy + hm[2]) / den - 0.5;
      var v = (hm[3] * xx + hm[4] * yy + hm[5]) / den - 0.5;
      if (u < 0) u = 0;
      if (v < 0) v = 0;
      if (u > sw - 1) u = (sw - 1).toDouble();
      if (v > sh - 1) v = (sh - 1).toDouble();
      final x0 = u.floor(), y0 = v.floor();
      final x1 = x0 + 1 < sw ? x0 + 1 : x0, y1 = y0 + 1 < sh ? y0 + 1 : y0;
      final fx = u - x0, fy = v - y0;
      final i00 = (y0 * sw + x0) * 3, i10 = (y0 * sw + x1) * 3;
      final i01 = (y1 * sw + x0) * 3, i11 = (y1 * sw + x1) * 3;
      for (var c = 0; c < 3; c++) {
        final top = sd[i00 + c] + (sd[i10 + c] - sd[i00 + c]) * fx;
        final bot = sd[i01 + c] + (sd[i11 + c] - sd[i01 + c]) * fx;
        out[o++] = (top + (bot - top) * fy).round();
      }
    }
  }
  return RgbImage(W, H, out);
}

// ───────────────────────── تحسين الصورة ─────────────────────────

/// إزالة الظلال وتوحيد الإضاءة: تقدير لون الورق ثم القسمة عليه
RgbImage removeShadows(RgbImage im) {
  final w = im.width, h = im.height, d = im.data;
  final b = math.max(6, (math.max(w, h) / 100).round());
  final bw = (w + b - 1) ~/ b, bh = (h + b - 1) ~/ b;
  var bg = Uint8List(bw * bh * 3);
  for (var by = 0; by < bh; by++) {
    for (var bx = 0; bx < bw; bx++) {
      final x0 = bx * b, x1 = math.min(w, x0 + b), y0 = by * b, y1 = math.min(h, y0 + b);
      var m0 = 0, m1 = 0, m2 = 0;
      for (var y = y0; y < y1; y++) {
        var k = (y * w + x0) * 3;
        for (var x = x0; x < x1; x++) {
          if (d[k] > m0) m0 = d[k];
          if (d[k + 1] > m1) m1 = d[k + 1];
          if (d[k + 2] > m2) m2 = d[k + 2];
          k += 3;
        }
      }
      final o = (by * bw + bx) * 3;
      bg[o] = m0;
      bg[o + 1] = m1;
      bg[o + 2] = m2;
    }
  }
  // توسيع (أقصى 3x3) ثم تنعيم
  final dil = Uint8List(bg.length);
  for (var y = 0; y < bh; y++) {
    for (var x = 0; x < bw; x++) {
      for (var c = 0; c < 3; c++) {
        var m = 0;
        for (var dy = -1; dy <= 1; dy++) {
          final yy = y + dy;
          if (yy < 0 || yy >= bh) continue;
          for (var dx = -1; dx <= 1; dx++) {
            final xx = x + dx;
            if (xx < 0 || xx >= bw) continue;
            final v = bg[(yy * bw + xx) * 3 + c];
            if (v > m) m = v;
          }
        }
        dil[(y * bw + x) * 3 + c] = m;
      }
    }
  }
  bg = _boxBlurC(dil, bw, bh, 3, 1);

  // جداول الاستيفاء
  final x0s = Int32List(w), x1s = Int32List(w);
  final txs = Float32List(w);
  for (var x = 0; x < w; x++) {
    final fx = (x + 0.5) / b - 0.5;
    var i0 = fx.floor();
    txs[x] = fx - i0;
    var i1 = i0 + 1;
    if (i0 < 0) i0 = 0;
    if (i1 >= bw) i1 = bw - 1;
    if (i0 >= bw) i0 = bw - 1;
    x0s[x] = i0;
    x1s[x] = i1;
  }
  final out = Uint8List(w * h * 3);
  for (var y = 0; y < h; y++) {
    final fy = (y + 0.5) / b - 0.5;
    var j0 = fy.floor();
    final ty = fy - j0;
    var j1 = j0 + 1;
    if (j0 < 0) j0 = 0;
    if (j1 >= bh) j1 = bh - 1;
    if (j0 >= bh) j0 = bh - 1;
    for (var x = 0; x < w; x++) {
      final tx = txs[x];
      final a = (j0 * bw + x0s[x]) * 3, bb = (j0 * bw + x1s[x]) * 3;
      final c = (j1 * bw + x0s[x]) * 3, dd = (j1 * bw + x1s[x]) * 3;
      final k = (y * w + x) * 3;
      for (var ch = 0; ch < 3; ch++) {
        final top = bg[a + ch] + (bg[bb + ch] - bg[a + ch]) * tx;
        final bot = bg[c + ch] + (bg[dd + ch] - bg[c + ch]) * tx;
        var bv = top + (bot - top) * ty;
        if (bv < 24) bv = 24;
        out[k + ch] = _clamp255(d[k + ch] * 255 / bv);
      }
    }
  }
  return RgbImage(w, h, out);
}

RgbImage _levels(RgbImage im, double lowPct, double highPct) {
  final d = im.data;
  final hist = List<int>.filled(256, 0);
  for (var i = 0; i < d.length; i += 3) {
    hist[(d[i] * 77 + d[i + 1] * 150 + d[i + 2] * 29) >> 8]++;
  }
  final total = im.width * im.height;
  var acc = 0, lo = 0, hi = 255;
  for (var v = 0; v < 256; v++) {
    acc += hist[v];
    if (acc >= total * lowPct / 100) {
      lo = v;
      break;
    }
  }
  acc = 0;
  for (var v = 255; v >= 0; v--) {
    acc += hist[v];
    if (acc >= total * (100 - highPct) / 100) {
      hi = v;
      break;
    }
  }
  if (hi - lo < 40) return im;
  final lut = Uint8List(256);
  for (var v = 0; v < 256; v++) {
    lut[v] = _clamp255((v - lo) * 255 / (hi - lo));
  }
  final out = Uint8List(d.length);
  for (var i = 0; i < d.length; i++) {
    out[i] = lut[d[i]];
  }
  return RgbImage(im.width, im.height, out);
}

RgbImage sharpen(RgbImage im, double amount) {
  final blur = _boxBlurC(im.data, im.width, im.height, 3, 1);
  final d = im.data;
  final out = Uint8List(d.length);
  for (var i = 0; i < d.length; i++) {
    out[i] = _clamp255(d[i] + amount * (d[i] - blur[i]));
  }
  return RgbImage(im.width, im.height, out);
}

RgbImage _toGray(RgbImage im) {
  final d = im.data;
  final out = Uint8List(d.length);
  for (var i = 0; i < d.length; i += 3) {
    final g = (d[i] * 77 + d[i + 1] * 150 + d[i + 2] * 29) >> 8;
    out[i] = g;
    out[i + 1] = g;
    out[i + 2] = g;
  }
  return RgbImage(im.width, im.height, out);
}

RgbImage _magic(RgbImage im) {
  final s = removeShadows(im);
  final d = s.data;
  final lut = Uint8List(256);
  for (var v = 0; v < 256; v++) {
    final x = ((v / 255 - 0.15) / (0.90 - 0.15)).clamp(0.0, 1.0);
    lut[v] = (x * 255).round();
  }
  final out = Uint8List(d.length);
  for (var i = 0; i < d.length; i += 3) {
    final r = lut[d[i]], g = lut[d[i + 1]], b = lut[d[i + 2]];
    final gr = (r * 77 + g * 150 + b * 29) >> 8;
    out[i] = _clamp255(gr + (r - gr) * 1.2);
    out[i + 1] = _clamp255(gr + (g - gr) * 1.2);
    out[i + 2] = _clamp255(gr + (b - gr) * 1.2);
  }
  return sharpen(RgbImage(s.width, s.height, out), 0.6);
}

RgbImage _blackWhite(RgbImage im) {
  final g = _toGray(removeShadows(im));
  final w = g.width, h = g.height;
  // صورة تكاملية لحساب المتوسط المحلي (Bradley)
  final integral = Int32List((w + 1) * (h + 1));
  for (var y = 0; y < h; y++) {
    var row = 0;
    for (var x = 0; x < w; x++) {
      row += g.data[(y * w + x) * 3];
      integral[(y + 1) * (w + 1) + x + 1] = integral[y * (w + 1) + x + 1] + row;
    }
  }
  final r = math.max(8, math.max(w, h) ~/ 40);
  final out = Uint8List(g.data.length);
  for (var y = 0; y < h; y++) {
    final y0 = math.max(0, y - r), y1 = math.min(h - 1, y + r);
    for (var x = 0; x < w; x++) {
      final x0 = math.max(0, x - r), x1 = math.min(w - 1, x + r);
      final cnt = (x1 - x0 + 1) * (y1 - y0 + 1);
      final sum = integral[(y1 + 1) * (w + 1) + x1 + 1] -
          integral[y0 * (w + 1) + x1 + 1] -
          integral[(y1 + 1) * (w + 1) + x0] +
          integral[y0 * (w + 1) + x0];
      final mean = sum / cnt;
      final v = g.data[(y * w + x) * 3];
      final bit = v < mean * 0.88 ? 0 : 255;
      final k = (y * w + x) * 3;
      out[k] = bit;
      out[k + 1] = bit;
      out[k + 2] = bit;
    }
  }
  return RgbImage(w, h, out);
}

RgbImage applyFilter(RgbImage im, int filter) {
  switch (filter) {
    case kFilterAuto:
      return sharpen(_levels(im, 0.5, 99.5), 0.4);
    case kFilterMagic:
      return _magic(im);
    case kFilterBW:
      return _blackWhite(im);
    case kFilterGray:
      return _levels(_toGray(removeShadows(im)), 1, 99);
    default:
      return im;
  }
}

RgbImage adjust(RgbImage im, double brightness, double contrast) {
  if (brightness == 0 && contrast == 1) return im;
  final lut = Uint8List(256);
  for (var v = 0; v < 256; v++) {
    lut[v] = _clamp255((v - 128) * contrast + 128 + brightness * 255);
  }
  final d = im.data;
  final out = Uint8List(d.length);
  for (var i = 0; i < d.length; i++) {
    out[i] = lut[d[i]];
  }
  return RgbImage(im.width, im.height, out);
}

RgbImage rotateQuarter(RgbImage im, int turns) {
  turns = ((turns % 4) + 4) % 4;
  if (turns == 0) return im;
  final w = im.width, h = im.height, d = im.data;
  final nw = turns == 2 ? w : h, nh = turns == 2 ? h : w;
  final out = Uint8List(nw * nh * 3);
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      int nx, ny;
      if (turns == 1) {
        nx = h - 1 - y;
        ny = x;
      } else if (turns == 2) {
        nx = w - 1 - x;
        ny = h - 1 - y;
      } else {
        nx = y;
        ny = w - 1 - x;
      }
      final s = (y * w + x) * 3, t = (ny * nw + nx) * 3;
      out[t] = d[s];
      out[t + 1] = d[s + 1];
      out[t + 2] = d[s + 2];
    }
  }
  return RgbImage(nw, nh, out);
}

// ───────────────────────── نقاط الدخول لـ Isolate ─────────────────────────

List<Pt> _cornersFrom(List<dynamic>? c, int w, int h) {
  if (c == null || c.length != 8) return [for (final p in defaultCorners()) Pt(p.x * w, p.y * h)];
  return [for (var i = 0; i < 4; i++) Pt((c[2 * i] as num).toDouble() * w, (c[2 * i + 1] as num).toDouble() * h)];
}

/// ينسخ الصورة الأصلية بعد تصحيح الاتجاه وتصغيرها، ويكتشف الحواف
Map<String, Object?> normalizeAndDetect(Map<String, Object?> a) {
  final bytes = (a['bytes'] as Uint8List?) ?? File(a['src'] as String).readAsBytesSync();
  final im = decodeToRgb(bytes, maxSide: (a['maxSide'] as int?) ?? 3200);
  File(a['out'] as String).writeAsBytesSync(encodeJpegRgb(im, quality: 92));
  List<double> corners = [for (final p in defaultCorners()) ...[p.x, p.y]];
  var found = false;
  if (a['detect'] == true) {
    final r = detectQuad(rgbToGraySmall(im, 480));
    if (r != null) {
      corners = [for (final p in r.corners) ...[p.x, p.y]];
      found = true;
    }
  }
  return {'w': im.width, 'h': im.height, 'corners': corners, 'found': found};
}

RgbImage _cropAndWarp(RgbImage src, List<dynamic>? corners, int maxSide) {
  if (corners == null) return src;
  return warpQuad(src, _cornersFrom(corners, src.width, src.height), maxSide: maxSide);
}

/// المعالجة الكاملة: قص + منظور + فلتر + سطوع/تباين + تدوير → JPEG
Map<String, Object?> processEntry(Map<String, Object?> a) {
  final maxSide = (a['maxSide'] as int?) ?? 2600;
  final src = decodeToRgb(File(a['path'] as String).readAsBytesSync(), maxSide: 3200);
  var out = _cropAndWarp(src, a['corners'] as List<dynamic>?, maxSide);
  out = applyFilter(out, (a['filter'] as int?) ?? 0);
  out = adjust(out, ((a['brightness'] as num?) ?? 0).toDouble(), ((a['contrast'] as num?) ?? 1).toDouble());
  out = rotateQuarter(out, (a['rotation'] as int?) ?? 0);
  return {
    'bytes': encodeJpegRgb(out, quality: (a['quality'] as int?) ?? 90),
    'w': out.width,
    'h': out.height,
  };
}

/// معاينات مصغّرة لكل الفلاتر
Map<String, Object?> previewFiltersEntry(Map<String, Object?> a) {
  final src = decodeToRgb(File(a['path'] as String).readAsBytesSync(), maxSide: 1200);
  final base = _cropAndWarp(src, a['corners'] as List<dynamic>?, 260);
  final rot = (a['rotation'] as int?) ?? 0;
  final thumbs = <Uint8List>[];
  for (var f = 0; f < kFilterCount; f++) {
    thumbs.add(encodeJpegRgb(rotateQuarter(applyFilter(base, f), rot), quality: 70));
  }
  return {'thumbs': thumbs};
}

/// تحويل RGBA خام إلى JPEG (بعد رسم التعليقات على الصورة)
Uint8List encodeRgbaEntry(Map<String, Object?> a) {
  final rgba = a['rgba'] as Uint8List;
  final w = a['w'] as int, h = a['h'] as int;
  final rgb = Uint8List(w * h * 3);
  var j = 0;
  for (var i = 0; i < rgba.length; i += 4) {
    rgb[j++] = rgba[i];
    rgb[j++] = rgba[i + 1];
    rgb[j++] = rgba[i + 2];
  }
  return encodeJpegRgb(RgbImage(w, h, rgb), quality: (a['quality'] as int?) ?? 92);
}

/// إعادة ضغط JPEG بحجم وجودة أقل (لضغط ملفات PDF)
Map<String, Object?> recompressEntry(Map<String, Object?> a) {
  final src = decodeToRgb(File(a['path'] as String).readAsBytesSync(), maxSide: a['maxSide'] as int);
  return {'bytes': encodeJpegRgb(src, quality: a['quality'] as int), 'w': src.width, 'h': src.height};
}

/// اكتشاف الحواف لصورة محفوظة (زر "اكتشاف تلقائي")
Map<String, Object?> detectEntry(Map<String, Object?> a) {
  final im = decodeToRgb(File(a['path'] as String).readAsBytesSync(), maxSide: 1000);
  final r = detectQuad(rgbToGraySmall(im, 480));
  if (r == null) {
    return {'found': false, 'corners': [for (final p in defaultCorners()) ...[p.x, p.y]]};
  }
  return {'found': true, 'corners': [for (final p in r.corners) ...[p.x, p.y]]};
}
