import 'dart:convert';

class FolderModel {
  final int? id;
  final String name;
  final int color;
  const FolderModel({this.id, required this.name, this.color = 0xFF1565C0});

  factory FolderModel.fromMap(Map<String, Object?> m) =>
      FolderModel(id: m['id'] as int?, name: m['name'] as String, color: (m['color'] as int?) ?? 0xFF1565C0);
}

class DocModel {
  final int id;
  final String title;
  final int? folderId;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<String> tags;
  final bool favorite;
  final bool locked;
  final String ocrText;
  final int pageCount;
  final String? cover;

  const DocModel({
    required this.id,
    required this.title,
    this.folderId,
    required this.createdAt,
    required this.updatedAt,
    this.tags = const [],
    this.favorite = false,
    this.locked = false,
    this.ocrText = '',
    this.pageCount = 0,
    this.cover,
  });

  factory DocModel.fromMap(Map<String, Object?> m) => DocModel(
        id: m['id'] as int,
        title: m['title'] as String,
        folderId: m['folder_id'] as int?,
        createdAt: DateTime.fromMillisecondsSinceEpoch(m['created_at'] as int),
        updatedAt: DateTime.fromMillisecondsSinceEpoch(m['updated_at'] as int),
        tags: ((m['tags'] as String?) ?? '').split(',').map((t) => t.trim()).where((t) => t.isNotEmpty).toList(),
        favorite: (m['favorite'] as int?) == 1,
        locked: (m['locked'] as int?) == 1,
        ocrText: (m['ocr_text'] as String?) ?? '',
        pageCount: (m['page_count'] as int?) ?? 0,
        cover: m['cover'] as String?,
      );
}

class PageModel {
  final int id;
  final int docId;
  final int position;
  final String origPath;
  final String procPath;
  final String? finalPath;
  final int origW, origH;
  final List<double> corners;
  final int filter;
  final int rotation;
  final double brightness;
  final double contrast;
  final String annotations; // JSON
  final String ocrText;
  final int width, height;

  const PageModel({
    required this.id,
    required this.docId,
    required this.position,
    required this.origPath,
    required this.procPath,
    this.finalPath,
    this.origW = 0,
    this.origH = 0,
    this.corners = const [],
    this.filter = 0,
    this.rotation = 0,
    this.brightness = 0,
    this.contrast = 1,
    this.annotations = '[]',
    this.ocrText = '',
    this.width = 0,
    this.height = 0,
  });

  String get displayPath => finalPath ?? procPath;

  factory PageModel.fromMap(Map<String, Object?> m) => PageModel(
        id: m['id'] as int,
        docId: m['doc_id'] as int,
        position: m['position'] as int,
        origPath: m['orig_path'] as String,
        procPath: m['proc_path'] as String,
        finalPath: m['final_path'] as String?,
        origW: (m['orig_w'] as int?) ?? 0,
        origH: (m['orig_h'] as int?) ?? 0,
        corners: ((jsonDecode((m['corners'] as String?) ?? '[]')) as List).map((e) => (e as num).toDouble()).toList(),
        filter: (m['filter'] as int?) ?? 0,
        rotation: (m['rotation'] as int?) ?? 0,
        brightness: ((m['brightness'] as num?) ?? 0).toDouble(),
        contrast: ((m['contrast'] as num?) ?? 1).toDouble(),
        annotations: (m['annotations'] as String?) ?? '[]',
        ocrText: (m['ocr_text'] as String?) ?? '',
        width: (m['width'] as int?) ?? 0,
        height: (m['height'] as int?) ?? 0,
      );
}

/// حالة تحرير صفحة (للمسودات قبل الحفظ ولتعديل الصفحات المحفوظة)
class PageEdit {
  final int uid;
  String origPath;
  int origW, origH;
  List<double> corners;
  int filter;
  int rotation;
  double brightness;
  double contrast;
  String? thumbPath;
  bool busy;

  PageEdit({
    required this.uid,
    required this.origPath,
    required this.origW,
    required this.origH,
    required this.corners,
    this.filter = 1,
    this.rotation = 0,
    this.brightness = 0,
    this.contrast = 1,
    this.thumbPath,
    this.busy = false,
  });

  PageEdit copy() => PageEdit(
        uid: uid,
        origPath: origPath,
        origW: origW,
        origH: origH,
        corners: List.of(corners),
        filter: filter,
        rotation: rotation,
        brightness: brightness,
        contrast: contrast,
        thumbPath: thumbPath,
        busy: busy,
      );

  void setFrom(PageEdit o) {
    corners = List.of(o.corners);
    filter = o.filter;
    rotation = o.rotation;
    brightness = o.brightness;
    contrast = o.contrast;
  }

  factory PageEdit.fromPage(PageModel p) => PageEdit(
        uid: p.id,
        origPath: p.origPath,
        origW: p.origW,
        origH: p.origH,
        corners: p.corners.length == 8 ? List.of(p.corners) : [0.03, 0.03, 0.97, 0.03, 0.97, 0.97, 0.03, 0.97],
        filter: p.filter,
        rotation: p.rotation,
        brightness: p.brightness,
        contrast: p.contrast,
      );
}
