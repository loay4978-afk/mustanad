import 'dart:convert';

import 'package:sqflite/sqflite.dart';

import '../../core/storage.dart';
import '../models/models.dart';

class AppDb {
  AppDb._();
  static final AppDb instance = AppDb._();

  Database? _db;
  Future<Database> get database async => _db ??= await _open();

  Future<Database> _open() async {
    return openDatabase(
      await Storage.dbPath(),
      version: 1,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: (db, v) async {
        await db.execute('CREATE TABLE folders(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, color INTEGER NOT NULL)');
        await db.execute('''CREATE TABLE documents(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, folder_id INTEGER,
          created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, tags TEXT NOT NULL DEFAULT '',
          favorite INTEGER NOT NULL DEFAULT 0, locked INTEGER NOT NULL DEFAULT 0, ocr_text TEXT NOT NULL DEFAULT '')''');
        await db.execute('''CREATE TABLE pages(
          id INTEGER PRIMARY KEY AUTOINCREMENT, doc_id INTEGER NOT NULL, position INTEGER NOT NULL,
          orig_path TEXT NOT NULL, proc_path TEXT NOT NULL, final_path TEXT,
          orig_w INTEGER, orig_h INTEGER, corners TEXT, filter INTEGER NOT NULL DEFAULT 0,
          rotation INTEGER NOT NULL DEFAULT 0, brightness REAL NOT NULL DEFAULT 0, contrast REAL NOT NULL DEFAULT 1,
          annotations TEXT NOT NULL DEFAULT '[]', ocr_text TEXT NOT NULL DEFAULT '',
          width INTEGER, height INTEGER,
          FOREIGN KEY(doc_id) REFERENCES documents(id) ON DELETE CASCADE)''');
        await db.execute('CREATE TABLE signatures(id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT NOT NULL)');
        await db.execute('CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)');
        await db.execute('CREATE INDEX idx_pages_doc ON pages(doc_id, position)');
      },
    );
  }

  Future<void> close() async {
    await _db?.close();
    _db = null;
  }

  // الإعدادات
  Future<String?> getSetting(String key) async {
    final r = await (await database).query('settings', where: 'key = ?', whereArgs: [key]);
    return r.isEmpty ? null : r.first['value'] as String?;
  }

  Future<void> setSetting(String key, String value) async => (await database)
      .insert('settings', {'key': key, 'value': value}, conflictAlgorithm: ConflictAlgorithm.replace);

  // المجلدات
  Future<List<FolderModel>> getFolders() async =>
      (await (await database).query('folders', orderBy: 'name')).map(FolderModel.fromMap).toList();

  Future<int> insertFolder(String name, int color) async =>
      (await database).insert('folders', {'name': name, 'color': color});

  Future<void> renameFolder(int id, String name) async =>
      (await database).update('folders', {'name': name}, where: 'id = ?', whereArgs: [id]);

  Future<void> deleteFolder(int id) async {
    final d = await database;
    await d.update('documents', {'folder_id': null}, where: 'folder_id = ?', whereArgs: [id]);
    await d.delete('folders', where: 'id = ?', whereArgs: [id]);
  }

  // المستندات
  Future<List<DocModel>> getDocs() async {
    final r = await (await database).rawQuery('''
      SELECT d.*,
        (SELECT COUNT(*) FROM pages p WHERE p.doc_id = d.id) AS page_count,
        (SELECT COALESCE(p.final_path, p.proc_path) FROM pages p WHERE p.doc_id = d.id ORDER BY p.position LIMIT 1) AS cover
      FROM documents d ORDER BY d.updated_at DESC''');
    return r.map(DocModel.fromMap).toList();
  }

  Future<int> insertDoc(String title, int? folderId) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    return (await database).insert('documents', {'title': title, 'folder_id': folderId, 'created_at': now, 'updated_at': now});
  }

  Future<void> updateDoc(int id, Map<String, Object?> values, {bool touch = true}) async {
    final v = Map<String, Object?>.from(values);
    if (touch) v['updated_at'] = DateTime.now().millisecondsSinceEpoch;
    await (await database).update('documents', v, where: 'id = ?', whereArgs: [id]);
  }

  /// يحذف المستند ويرجع مسارات ملفاته لحذفها
  Future<List<String>> deleteDoc(int id) async {
    final d = await database;
    final pages = await getPages(id);
    final files = <String>[for (final p in pages) ...[p.origPath, p.procPath, if (p.finalPath != null) p.finalPath!]];
    await d.delete('documents', where: 'id = ?', whereArgs: [id]);
    return files;
  }

  // الصفحات
  Future<List<PageModel>> getPages(int docId) async => (await (await database)
          .query('pages', where: 'doc_id = ?', whereArgs: [docId], orderBy: 'position, id'))
      .map(PageModel.fromMap)
      .toList();

  Future<int> insertPage(int docId, int position,
      {required String origPath,
      required String procPath,
      required int origW,
      required int origH,
      required List<double> corners,
      required int filter,
      required int rotation,
      required double brightness,
      required double contrast,
      required int width,
      required int height,
      String ocrText = ''}) async {
    return (await database).insert('pages', {
      'doc_id': docId,
      'position': position,
      'orig_path': origPath,
      'proc_path': procPath,
      'orig_w': origW,
      'orig_h': origH,
      'corners': jsonEncode(corners),
      'filter': filter,
      'rotation': rotation,
      'brightness': brightness,
      'contrast': contrast,
      'width': width,
      'height': height,
      'ocr_text': ocrText,
    });
  }

  Future<void> updatePage(int id, Map<String, Object?> values) async =>
      (await database).update('pages', values, where: 'id = ?', whereArgs: [id]);

  Future<void> deletePage(int id) async => (await database).delete('pages', where: 'id = ?', whereArgs: [id]);

  Future<void> setPositions(List<int> pageIdsInOrder) async {
    final batch = (await database).batch();
    for (var i = 0; i < pageIdsInOrder.length; i++) {
      batch.update('pages', {'position': i}, where: 'id = ?', whereArgs: [pageIdsInOrder[i]]);
    }
    await batch.commit(noResult: true);
  }

  Future<void> movePage(int pageId, int docId, int position) async =>
      (await database).update('pages', {'doc_id': docId, 'position': position}, where: 'id = ?', whereArgs: [pageId]);

  // التوقيعات
  Future<List<Map<String, Object?>>> getSignatures() async => (await database).query('signatures', orderBy: 'id DESC');
  Future<int> insertSignature(String path) async => (await database).insert('signatures', {'path': path});
  Future<void> deleteSignature(int id) async => (await database).delete('signatures', where: 'id = ?', whereArgs: [id]);
}
