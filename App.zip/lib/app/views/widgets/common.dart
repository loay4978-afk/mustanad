import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controllers/app_controller.dart';
import '../../controllers/docs_controller.dart';
import '../../core/utils.dart';
import '../../data/models/models.dart';

class FileThumb extends StatelessWidget {
  final String? path;
  final double? width, height;
  final BoxFit fit;
  const FileThumb({super.key, this.path, this.width, this.height, this.fit = BoxFit.cover});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    if (path == null || !File(path!).existsSync()) {
      return Container(width: width, height: height, color: cs.surfaceContainerHighest, child: const Icon(Icons.description_outlined));
    }
    return Image.file(
      File(path!),
      key: ValueKey(path),
      width: width,
      height: height,
      fit: fit,
      cacheWidth: 400,
      errorBuilder: (_, __, ___) => Container(width: width, height: height, color: cs.surfaceContainerHighest, child: const Icon(Icons.broken_image_outlined)),
    );
  }
}

/// يطلب PIN التطبيق ويتحقق منه
Future<bool> askPin({String? title}) async {
  final app = Get.find<AppController>();
  if (!app.hasPin.value) return true;
  final pin = await askText(title ?? 'Enter PIN'.tr, obscure: true, keyboard: TextInputType.number);
  if (pin == null) return false;
  final ok = await app.verifyPin(pin);
  if (!ok) toast('Notice'.tr, 'Wrong PIN'.tr, error: true);
  return ok;
}

/// يتأكد أن المستند المقفل مفتوح في هذه الجلسة
Future<bool> ensureUnlocked(DocModel d) async {
  final dc = Get.find<DocsController>();
  if (!d.locked || dc.unlocked.contains(d.id)) return true;
  final ok = await askPin(title: 'Document is locked'.tr);
  if (ok) dc.unlocked.add(d.id);
  return ok;
}

/// شاشة قفل التطبيق (PIN)
class LockScreen extends StatefulWidget {
  const LockScreen({super.key});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final ctrl = TextEditingController();
  bool bad = false;

  Future<void> _try() async {
    final app = Get.find<AppController>();
    if (await app.verifyPin(ctrl.text)) {
      app.sessionUnlocked.value = true;
    } else {
      setState(() => bad = true);
      ctrl.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock_outline, size: 56),
              const SizedBox(height: 16),
              Text('Enter PIN'.tr, style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 16),
              SizedBox(
                width: 220,
                child: TextField(
                  controller: ctrl,
                  obscureText: true,
                  autofocus: true,
                  textAlign: TextAlign.center,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(errorText: bad ? 'Wrong PIN'.tr : null),
                  onSubmitted: (_) => _try(),
                ),
              ),
              const SizedBox(height: 16),
              FilledButton(onPressed: _try, child: Text('Unlock'.tr)),
            ],
          ),
        ),
      ),
    );
  }
}
