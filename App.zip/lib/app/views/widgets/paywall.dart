import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controllers/app_controller.dart';

const List<String> kProFeatures = [
  'No watermark on PDF files',
  'Invoice data extraction',
  'Backup and restore',
  'All future Pro features',
];

Future<void> showPaywall(String feature) async {
  final app = Get.find<AppController>();
  await Get.dialog(AlertDialog(
    title: Row(children: [
      const Icon(Icons.workspace_premium, color: Colors.amber),
      const SizedBox(width: 8),
      Text('Mustanad Pro'.tr),
    ]),
    content: Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Unlock: @f'.trParams({'f': feature.tr}), style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        for (final f in kProFeatures)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(children: [
              const Icon(Icons.check_circle, size: 18, color: Colors.green),
              const SizedBox(width: 8),
              Expanded(child: Text(f.tr)),
            ]),
          ),
        const SizedBox(height: 12),
        Text('Store billing is not connected in this build. Use test activation to try Pro features.'.tr,
            style: Theme.of(Get.context!).textTheme.bodySmall),
      ],
    ),
    actions: [
      TextButton(onPressed: () => Get.back(), child: Text('Not now'.tr)),
      FilledButton(
        onPressed: () async {
          await app.setPro(true);
          Get.back();
        },
        child: Text('Activate Pro (test)'.tr),
      ),
    ],
  ));
}
