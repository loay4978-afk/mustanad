import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'package:share_plus/share_plus.dart';

import '../controllers/app_controller.dart';
import '../controllers/docs_controller.dart';
import '../controllers/tools_controller.dart';
import '../core/pdf_service.dart';
import '../core/utils.dart';
import '../data/models/models.dart';
import 'doc_detail_view.dart';
import 'nav.dart';

class ToolsView extends StatelessWidget {
  const ToolsView({super.key});

  Future<void> _withProgress(String msg, RxInt progress, Future<void> Function() job) async {
    Get.dialog(
      PopScope(
        canPop: false,
        child: AlertDialog(
          content: Obx(() => Row(children: [
                const CircularProgressIndicator(),
                const SizedBox(width: 20),
                Expanded(child: Text(progress.value > 0 ? '$msg (${progress.value})' : msg)),
              ])),
        ),
      ),
      barrierDismissible: false,
    );
    try {
      await job();
    } catch (e) {
      toast('Error'.tr, 'Operation failed'.tr, error: true);
    } finally {
      if (Get.isDialogOpen == true) Get.back();
    }
  }

  Future<void> _mergeDocs() async {
    final dc = Get.find<DocsController>();
    if (dc.docs.length < 2) {
      toast('Notice'.tr, 'You need at least two documents'.tr, error: true);
      return;
    }
    final chosen = <int>[];
    final ok = await Get.dialog<bool>(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text('Select documents to merge'.tr),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(shrinkWrap: true, children: [
            for (final d in dc.docs)
              CheckboxListTile(
                value: chosen.contains(d.id),
                title: Text(d.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('@n pages'.trParams({'n': '${d.pageCount}'})),
                onChanged: (v) => setState(() => v == true ? chosen.add(d.id) : chosen.remove(d.id)),
              ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: Text('Cancel'.tr)),
          FilledButton(onPressed: chosen.length < 2 ? null : () => Get.back(result: true), child: Text('Merge'.tr)),
        ],
      ),
    ));
    if (ok != true) return;
    final title = await askText('New document title'.tr, initial: 'Merged ${DateFormat('yyyy-MM-dd').format(DateTime.now())}');
    if (title == null || title.trim().isEmpty) return;
    final id = await dc.mergeDocs(chosen, title.trim(), null);
    Get.to(() => DocDetailView(docId: id));
  }

  Future<void> _splitDoc() async {
    final dc = Get.find<DocsController>();
    if (dc.docs.isEmpty) return;
    final d = await Get.dialog<DocModel>(SimpleDialog(title: Text('Choose a document'.tr), children: [
      for (final x in dc.docs) SimpleDialogOption(onPressed: () => Get.back(result: x), child: Text('${x.title} (${x.pageCount})')),
    ]));
    if (d == null) return;
    final r = await askText('Pages to extract, e.g. 1-3,5'.tr, hint: '1-3,5');
    if (r == null) return;
    final pages = await dc.pages(d.id);
    final idx = parseRanges(r, pages.length);
    if (idx.isEmpty) {
      toast('Notice'.tr, 'No valid pages selected'.tr, error: true);
      return;
    }
    final t = await askText('New document title'.tr, initial: '${d.title} (part)');
    if (t == null || t.trim().isEmpty) return;
    final id = await dc.extractPages([for (final i in idx) pages[i - 1]], t.trim(), d.folderId);
    if (id != null) Get.to(() => DocDetailView(docId: id));
  }

  Future<void> _compress() async {
    final tc = Get.find<ToolsController>();
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    final path = r?.files.single.path;
    if (path == null) return;
    int q = 1;
    final ok = await Get.dialog<bool>(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text('Compress PDF'.tr),
        content: Wrap(spacing: 8, children: [
          ChoiceChip(label: Text('Medium (smaller)'.tr), selected: q == 1, onSelected: (_) => setState(() => q = 1)),
          ChoiceChip(label: Text('Low (smallest)'.tr), selected: q == 2, onSelected: (_) => setState(() => q = 2)),
        ]),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: Text('Cancel'.tr)),
          FilledButton(onPressed: () => Get.back(result: true), child: Text('Compress'.tr)),
        ],
      ),
    ));
    if (ok != true) return;
    final before = File(path).lengthSync();
    final progress = 0.obs;
    File? out;
    await _withProgress('Compressing…'.tr, progress, () async {
      out = await tc.compressPdf(path, 'compressed', q, progress: progress);
    });
    if (out != null) {
      toast('PDF', 'Size: @a → @b'.trParams({'a': fmtBytes(before), 'b': fmtBytes(out!.lengthSync())}));
      await Share.shareXFiles([XFile(out!.path)]);
    }
  }

  Future<void> _splitPdf() async {
    final tc = Get.find<ToolsController>();
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    final path = r?.files.single.path;
    if (path == null) return;
    final ranges = await askText('Pages to extract, e.g. 1-3,5'.tr, hint: '1-3,5');
    if (ranges == null) return;
    final progress = 0.obs;
    File? out;
    await _withProgress('Extracting pages…'.tr, progress, () async {
      out = await tc.splitPdf(path, 'split', ranges, progress: progress);
    });
    if (out == null) {
      toast('Notice'.tr, 'No valid pages selected'.tr, error: true);
    } else {
      await Share.shareXFiles([XFile(out!.path)]);
    }
  }

  Future<void> _backup() async {
    final app = Get.find<AppController>();
    if (!await app.requirePro('Backup and restore')) return;
    final progress = 0.obs;
    File? f;
    await _withProgress('Creating backup…'.tr, progress, () async {
      f = await Get.find<ToolsController>().backup();
    });
    if (f != null) {
      toast('Backup'.tr, 'Backup ready: @s'.trParams({'s': fmtBytes(f!.lengthSync())}));
      await Share.shareXFiles([XFile(f!.path)], text: 'Mustanad backup');
    }
  }

  Future<void> _restore() async {
    final app = Get.find<AppController>();
    if (!await app.requirePro('Backup and restore')) return;
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['zip']);
    final path = r?.files.single.path;
    if (path == null) return;
    if (!await confirm('Restore backup'.tr, 'All current documents will be replaced. Continue?'.tr)) return;
    final progress = 0.obs;
    await _withProgress('Restoring…'.tr, progress, () async {
      await Get.find<ToolsController>().restore(path);
    });
    toast('Backup'.tr, 'Backup restored'.tr);
  }

  @override
  Widget build(BuildContext context) {
    Widget tile(IconData i, String t, String s, VoidCallback onTap, {bool pro = false}) => Card(
          child: ListTile(
            leading: CircleAvatar(child: Icon(i)),
            title: Row(children: [
              Flexible(child: Text(t.tr)),
              if (pro) ...[const SizedBox(width: 6), const Icon(Icons.workspace_premium, size: 16, color: Colors.amber)],
            ]),
            subtitle: Text(s.tr),
            onTap: onTap,
          ),
        );

    return Scaffold(
      appBar: AppBar(title: Text('Tools'.tr)),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        tile(Icons.merge_type, 'Merge documents', 'Combine several documents into one', _mergeDocs),
        tile(Icons.call_split, 'Split document', 'Extract selected pages into a new document', _splitDoc),
        tile(Icons.picture_as_pdf_outlined, 'Merge PDF files', 'Pick several PDFs and combine them', () => startPdfImport(multiple: true)),
        tile(Icons.content_cut, 'Split PDF file', 'Extract pages from a PDF file', _splitPdf),
        tile(Icons.compress, 'Compress PDF file', 'Reduce the size of a PDF', _compress),
        tile(Icons.picture_as_pdf, 'Import PDF', 'Turn PDF pages into an editable document', () => startPdfImport()),
        tile(Icons.photo_library_outlined, 'Import images', 'Convert photos into a document', () => startImport()),
        tile(Icons.cloud_upload_outlined, 'Backup', 'Save all documents as a file to any cloud', _backup, pro: true),
        tile(Icons.cloud_download_outlined, 'Restore backup', 'Restore documents from a backup file', _restore, pro: true),
      ]),
    );
  }
}
