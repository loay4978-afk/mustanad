import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../controllers/app_controller.dart';
import '../controllers/scan_controller.dart';
import '../core/utils.dart';
import '../engine/scanner_engine.dart';
import 'review_view.dart';

class CameraView extends StatefulWidget {
  final bool fromReview;
  const CameraView({super.key, this.fromReview = false});
  @override
  State<CameraView> createState() => _CameraViewState();
}

class _CameraViewState extends State<CameraView> {
  final sc = Get.find<ScanController>();
  final app = Get.find<AppController>();
  CameraController? _c;
  String? _error;
  bool _busy = false, _capturing = false, _flash = false;
  List<Offset>? _quad;
  int _stable = 0, _cool = 0;
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final cams = await availableCameras();
      if (cams.isEmpty) {
        setState(() => _error = 'No camera found'.tr);
        return;
      }
      final cam = cams.firstWhere((c) => c.lensDirection == CameraLensDirection.back, orElse: () => cams.first);
      final c = CameraController(
        cam,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: Platform.isAndroid ? ImageFormatGroup.yuv420 : ImageFormatGroup.bgra8888,
      );
      await c.initialize();
      try {
        await c.lockCaptureOrientation(DeviceOrientation.portraitUp);
      } catch (_) {}
      await c.setFlashMode(FlashMode.off);
      if (!mounted) {
        await c.dispose();
        return;
      }
      setState(() => _c = c);
      _startStream();
    } on CameraException catch (e) {
      if (mounted) setState(() => _error = e.description ?? e.code);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  void _startStream() {
    final c = _c;
    if (c == null || !c.value.isInitialized || c.value.isStreamingImages) return;
    try {
      c.startImageStream(_onFrame);
    } catch (_) {}
  }

  GrayImage _gray(CameraImage im) {
    final step = math.max(1, im.width ~/ 160);
    final w = im.width ~/ step, h = im.height ~/ step;
    final out = Uint8List(w * h);
    final pl = im.planes[0];
    final bytes = pl.bytes;
    final stride = pl.bytesPerRow;
    if (im.format.group == ImageFormatGroup.bgra8888) {
      for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++) {
          final k = (y * step) * stride + (x * step) * 4;
          out[y * w + x] = (bytes[k] * 29 + bytes[k + 1] * 150 + bytes[k + 2] * 77) >> 8;
        }
      }
    } else {
      for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++) {
          out[y * w + x] = bytes[(y * step) * stride + x * step];
        }
      }
    }
    return GrayImage(w, h, out);
  }

  Offset _up(Pt p, int o) {
    switch (o) {
      case 90:
        return Offset(1 - p.y, p.x);
      case 180:
        return Offset(1 - p.x, 1 - p.y);
      case 270:
        return Offset(p.y, 1 - p.x);
      default:
        return Offset(p.x, p.y);
    }
  }

  void _onFrame(CameraImage im) {
    final now = DateTime.now();
    if (_busy || _capturing || now.difference(_last).inMilliseconds < 320) return;
    _busy = true;
    _last = now;
    try {
      final r = detectQuad(_gray(im));
      final o = _c?.description.sensorOrientation ?? 90;
      List<Offset>? q = r == null ? null : [for (final p in r.corners) _up(p, o)];
      if (q != null && _quad != null && _quad!.length == 4) {
        var maxD = 0.0;
        for (var i = 0; i < 4; i++) {
          maxD = math.max(maxD, (q[i] - _quad![i]).distance);
          q[i] = Offset.lerp(_quad![i], q[i], 0.55)!;
        }
        _stable = maxD < 0.03 ? _stable + 1 : 0;
      } else {
        _stable = 0;
      }
      if (_cool > 0) _cool--;
      if (mounted) setState(() => _quad = q);
      if (q != null && app.autoCapture.value && _cool == 0 && _stable >= 5 && _area(q) > 0.2) {
        _shoot();
      }
    } finally {
      _busy = false;
    }
  }

  double _area(List<Offset> q) {
    var s = 0.0;
    for (var i = 0; i < 4; i++) {
      final a = q[i], b = q[(i + 1) % 4];
      s += a.dx * b.dy - b.dx * a.dy;
    }
    return s.abs() / 2;
  }

  Future<void> _shoot() async {
    final c = _c;
    if (c == null || _capturing || !c.value.isInitialized) return;
    setState(() => _capturing = true);
    try {
      if (c.value.isStreamingImages) await c.stopImageStream();
      final f = await c.takePicture();
      HapticFeedback.mediumImpact();
      sc.addFile(f.path);
    } catch (_) {
      toast('Camera'.tr, 'Capture failed'.tr, error: true);
    } finally {
      _stable = 0;
      _cool = 10;
      if (mounted) {
        setState(() {
          _capturing = false;
          _quad = null;
        });
        _startStream();
      }
    }
  }

  Future<void> _toggleFlash() async {
    final c = _c;
    if (c == null) return;
    _flash = !_flash;
    try {
      await c.setFlashMode(_flash ? FlashMode.torch : FlashMode.off);
    } catch (_) {}
    setState(() {});
  }

  void _done() {
    if (sc.drafts.isEmpty && sc.pending.value == 0) {
      toast('Camera'.tr, 'Take at least one photo'.tr, error: true);
      return;
    }
    if (widget.fromReview) {
      Get.back();
    } else {
      Get.off(() => const ReviewView());
    }
  }

  @override
  void dispose() {
    final c = _c;
    _c = null;
    () async {
      try {
        if (c != null && c.value.isStreamingImages) await c.stopImageStream();
      } catch (_) {}
      await c?.dispose();
    }();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = _c;
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.no_photography_outlined, color: Colors.white, size: 56),
                    const SizedBox(height: 12),
                    Text(_error!, style: const TextStyle(color: Colors.white), textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: () async {
                        final n = await sc.pickFromGallery();
                        if (n > 0) Get.off(() => const ReviewView());
                      },
                      child: Text('Import images'.tr),
                    ),
                    TextButton(onPressed: () => Get.back(), child: Text('Close'.tr)),
                  ]),
                ),
              )
            : c == null
                ? const Center(child: CircularProgressIndicator())
                : Column(children: [
                    // الشريط العلوي
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: Row(children: [
                        IconButton(icon: const Icon(Icons.close, color: Colors.white), onPressed: () => Get.back()),
                        const Spacer(),
                        Obx(() => FilterChip(
                              label: Text('Auto'.tr),
                              selected: app.autoCapture.value,
                              onSelected: app.setAutoCapture,
                              avatar: const Icon(Icons.auto_awesome, size: 16),
                            )),
                        IconButton(icon: Icon(_flash ? Icons.flash_on : Icons.flash_off, color: Colors.white), onPressed: _toggleFlash),
                      ]),
                    ),
                    Expanded(
                      child: Center(
                        child: AspectRatio(
                          aspectRatio: 1 / c.value.aspectRatio,
                          child: Stack(fit: StackFit.expand, children: [
                            CameraPreview(c),
                            if (_quad != null) CustomPaint(painter: _QuadOverlay(_quad!, _stable)),
                          ]),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        IconButton(
                          iconSize: 32,
                          icon: const Icon(Icons.photo_library_outlined, color: Colors.white),
                          onPressed: () => sc.pickFromGallery(),
                        ),
                        GestureDetector(
                          onTap: _shoot,
                          child: Container(
                            width: 74,
                            height: 74,
                            decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 4)),
                            padding: const EdgeInsets.all(5),
                            child: Container(
                              decoration: BoxDecoration(shape: BoxShape.circle, color: _capturing ? Colors.grey : Colors.white),
                            ),
                          ),
                        ),
                        Obx(() => Badge(
                              isLabelVisible: sc.drafts.isNotEmpty || sc.pending.value > 0,
                              label: Text('${sc.drafts.length + sc.pending.value}'),
                              child: IconButton.filled(
                                iconSize: 28,
                                icon: const Icon(Icons.check),
                                onPressed: _done,
                              ),
                            )),
                      ]),
                    ),
                  ]),
      ),
    );
  }
}

class _QuadOverlay extends CustomPainter {
  final List<Offset> q;
  final int stable;
  _QuadOverlay(this.q, this.stable);

  @override
  void paint(Canvas canvas, Size size) {
    final pts = [for (final p in q) Offset(p.dx * size.width, p.dy * size.height)];
    final path = Path()..moveTo(pts[0].dx, pts[0].dy);
    for (var i = 1; i < 4; i++) {
      path.lineTo(pts[i].dx, pts[i].dy);
    }
    path.close();
    final color = stable >= 3 ? Colors.greenAccent : Colors.lightBlueAccent;
    canvas.drawPath(path, Paint()..color = color.withOpacity(0.18));
    canvas.drawPath(path, Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 3);
    for (final p in pts) {
      canvas.drawCircle(p, 6, Paint()..color = color);
    }
  }

  @override
  bool shouldRepaint(covariant _QuadOverlay old) => true;
}
