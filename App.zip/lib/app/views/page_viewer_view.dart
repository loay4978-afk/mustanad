import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';

import '../controllers/docs_controller.dart';
import '../core/utils.dart';
import '../data/models/models.dart';
import 'annotate_view.dart';
import 'page_edit_view.dart';
import 'text_views.dart';

class PageViewerView extends StatefulWidget {
  final int docId;
  final int initial;
  const PageViewerView({super.key, required this.docId, this.initial = 0});
  @override
  State<PageViewerView> createState() => _PageViewerViewState();
}

class _PageViewerViewState extends State<PageViewerView> {
  final dc = Get.find<DocsController>();
  List<PageModel> pages = [];
  late PageController pc;
  int index = 0;
  Worker? _w;

  @override
  void initState() {
    super.initState();
    index = widget.initial;
    pc = PageController(initialPage: widget.initial);
    _load();
    _w = ever(dc.docs, (_) => _load());
  }

  @override
  void dispose() {
    _w?.dispose();
    pc.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final p = await dc.pages(widget.docId);
    if (!mounted) return;
    if (p.isEmpty) {
      Get.back();
      return;
    }
    setState(() {
      pages = p;
      if (index >= p.length) index = p.length - 1;
    });
  }

  PageModel get cur => pages[index];

  Future<void> _edit() async {
    final r = await Get.to<PageEdit>(() => PageEditView(edit: PageEdit.fromPage(cur)));
    if (r != null) {
      if (cur.annotations != '[]' && !await confirm('Edit page'.tr, 'Annotations on this page will be removed. Continue?'.tr)) return;
      await dc.updatePageFromEdit(cur, r);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (pages.isEmpty) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text('@i / @n'.trParams({'i': '${index + 1}', 'n': '${pages.length}'})),
        actions: [
          IconButton(icon: const Icon(Icons.crop_rotate), tooltip: 'Edit'.tr, onPressed: _edit),
          IconButton(
              icon: const Icon(Icons.draw_outlined),
              tooltip: 'Annotate and sign'.tr,
              onPressed: () => Get.to(() => AnnotateView(page: cur))),
          PopupMenuButton<String>(
            iconColor: Colors.white,
            onSelected: (v) async {
              if (v == 'text') {
                Get.to(() => PageTextView(page: cur));
              } else if (v == 'share') {
                await Share.shareXFiles([XFile(cur.displayPath)]);
              } else if (v == 'delete') {
                if (await confirm('Delete page'.tr, 'Delete this page?'.tr)) await dc.deletePages([cur]);
              }
            },
            itemBuilder: (_) => [
              PopupMenuItem(value: 'text', child: Text('Page text'.tr)),
              PopupMenuItem(value: 'share', child: Text('Share image'.tr)),
              PopupMenuItem(value: 'delete', child: Text('Delete page'.tr)),
            ],
          ),
        ],
      ),
      body: PageView.builder(
        controller: pc,
        itemCount: pages.length,
        onPageChanged: (i) => setState(() => index = i),
        itemBuilder: (_, i) => InteractiveViewer(
          minScale: 1,
          maxScale: 6,
          child: Center(child: Image.file(File(pages[i].displayPath), key: ValueKey(pages[i].displayPath), fit: BoxFit.contain)),
        ),
      ),
    );
  }
}
