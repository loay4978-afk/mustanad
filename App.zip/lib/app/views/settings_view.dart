import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/app_controller.dart';
import '../core/ocr_service.dart';
import '../core/utils.dart';

class SettingsView extends StatelessWidget {
  const SettingsView({super.key});

  Future<void> _pin(AppController app) async {
    if (app.hasPin.value) {
      final a = await Get.dialog<String>(SimpleDialog(title: Text('App lock (PIN)'.tr), children: [
        SimpleDialogOption(onPressed: () => Get.back(result: 'change'), child: Text('Change PIN'.tr)),
        SimpleDialogOption(onPressed: () => Get.back(result: 'remove'), child: Text('Remove PIN'.tr)),
      ]));
      if (a == null) return;
      final old = await askText('Enter PIN'.tr, obscure: true, keyboard: TextInputType.number);
      if (old == null || !await app.verifyPin(old)) {
        if (old != null) toast('Notice'.tr, 'Wrong PIN'.tr, error: true);
        return;
      }
      if (a == 'remove') {
        await app.clearPin();
        return;
      }
    }
    final p = await askText('Create a PIN (4+ digits)'.tr, obscure: true, keyboard: TextInputType.number);
    if (p == null) return;
    if (p.length < 4) {
      toast('Notice'.tr, 'PIN is too short'.tr, error: true);
      return;
    }
    await app.setPin(p);
    app.sessionUnlocked.value = true;
    toast('Security'.tr, 'PIN saved'.tr);
  }

  void _ocrLangs(AppController app) {
    Get.dialog(AlertDialog(
      title: Text('OCR languages'.tr),
      content: Obx(() => Column(mainAxisSize: MainAxisSize.min, children: [
            for (final e in OcrService.languages.entries)
              CheckboxListTile(
                value: app.ocrLangs.contains(e.key),
                title: Text(e.value),
                onChanged: (v) {
                  final l = app.ocrLangs.toList();
                  v == true ? l.add(e.key) : l.remove(e.key);
                  app.setOcrLangs(l);
                },
              ),
          ])),
      actions: [FilledButton(onPressed: () => Get.back(), child: Text('OK'.tr))],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final app = Get.find<AppController>();
    const qualityNames = ['High', 'Medium (smaller)', 'Low (smallest)'];
    const sizeNames = {'fit': 'Fit to image', 'a4': 'A4', 'letter': 'Letter'};
    return Scaffold(
      appBar: AppBar(title: Text('Settings'.tr)),
      body: Obx(() => ListView(children: [
            Card(
              margin: const EdgeInsets.all(12),
              color: app.isPro.value ? Colors.amber.shade100 : null,
              child: ListTile(
                leading: const Icon(Icons.workspace_premium, color: Colors.amber, size: 32),
                title: Text(app.isPro.value ? 'Mustanad Pro (active)'.tr : 'Free version'.tr, style: TextStyle(color: app.isPro.value ? Colors.black87 : null)),
                subtitle: Text(app.isPro.value ? 'Thank you for your support'.tr : 'Upgrade to remove the PDF watermark and unlock Pro tools'.tr,
                    style: TextStyle(color: app.isPro.value ? Colors.black54 : null)),
                trailing: app.isPro.value
                    ? TextButton(onPressed: () => app.setPro(false), child: Text('Deactivate (test)'.tr))
                    : FilledButton(onPressed: () => app.requirePro('All future Pro features'), child: Text('Upgrade'.tr)),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.language),
              title: Text('Language'.tr),
              subtitle: Text(const {'ar': 'العربية', 'en': 'English', 'de': 'Deutsch'}[app.lang.value] ?? 'English'),
              onTap: () => Get.dialog(SimpleDialog(title: Text('Language'.tr), children: [
                SimpleDialogOption(onPressed: () { app.setLang('ar'); Get.back(); }, child: const Text('العربية')),
                SimpleDialogOption(onPressed: () { app.setLang('en'); Get.back(); }, child: const Text('English')),
                SimpleDialogOption(onPressed: () { app.setLang('de'); Get.back(); }, child: const Text('Deutsch')),
              ])),
            ),
            SwitchListTile(
              secondary: const Icon(Icons.dark_mode_outlined),
              title: Text('Dark mode'.tr),
              value: app.themeMode.value == ThemeMode.dark,
              onChanged: app.setDark,
            ),
            const Divider(),
            _Section('Scanning'.tr),
            SwitchListTile(
              secondary: const Icon(Icons.auto_awesome),
              title: Text('Auto capture'.tr),
              subtitle: Text('Take the photo when the document edges are steady'.tr),
              value: app.autoCapture.value,
              onChanged: app.setAutoCapture,
            ),
            SwitchListTile(
              secondary: const Icon(Icons.text_snippet_outlined),
              title: Text('Recognize text automatically'.tr),
              subtitle: Text('Runs OCR in the background after saving'.tr),
              value: app.autoOcr.value,
              onChanged: app.setAutoOcr,
            ),
            ListTile(
              leading: const Icon(Icons.translate),
              title: Text('OCR languages'.tr),
              subtitle: Text(app.ocrLangs.map((c) => OcrService.languages[c] ?? c).join(' + ')),
              onTap: () => _ocrLangs(app),
            ),
            const Divider(),
            _Section('PDF'.tr),
            ListTile(
              leading: const Icon(Icons.compress),
              title: Text('Default quality'.tr),
              subtitle: Text(qualityNames[app.pdfQuality.value].tr),
              onTap: () => Get.dialog(SimpleDialog(title: Text('Default quality'.tr), children: [
                for (var i = 0; i < 3; i++) SimpleDialogOption(onPressed: () { app.setPdfQuality(i); Get.back(); }, child: Text(qualityNames[i].tr)),
              ])),
            ),
            ListTile(
              leading: const Icon(Icons.crop_portrait),
              title: Text('Default page size'.tr),
              subtitle: Text((sizeNames[app.pdfSize.value] ?? 'Fit to image').tr),
              onTap: () => Get.dialog(SimpleDialog(title: Text('Default page size'.tr), children: [
                for (final e in sizeNames.entries) SimpleDialogOption(onPressed: () { app.setPdfSize(e.key); Get.back(); }, child: Text(e.value.tr)),
              ])),
            ),
            const Divider(),
            _Section('Security'.tr),
            ListTile(
              leading: const Icon(Icons.lock_outline),
              title: Text('App lock (PIN)'.tr),
              subtitle: Text(app.hasPin.value ? 'Enabled'.tr : 'Off'.tr),
              onTap: () => _pin(app),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: Text('Documents never leave your phone unless you share or back them up. OCR works offline.'.tr, style: Theme.of(context).textTheme.bodySmall),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.info_outline),
              title: Text('Mustanad'.tr),
              subtitle: Text('Version 1.0.0'.tr),
            ),
            const SizedBox(height: 24),
          ])),
    );
  }
}

class _Section extends StatelessWidget {
  final String t;
  const _Section(this.t);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: Text(t, style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)),
      );
}
