import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../controllers/docs_controller.dart';
import '../controllers/scan_controller.dart';
import '../core/utils.dart';
import '../data/models/models.dart';
import 'camera_view.dart';
import 'doc_detail_view.dart';
import 'page_edit_view.dart';

class ReviewView extends StatelessWidget {
  const ReviewView({super.key});

  Future<void> _save() async {
    final sc = Get.find<ScanController>();
    final dc = Get.find<DocsController>();
    if (sc.pending.value > 0) {
      toast('Please wait'.tr, 'Pages are still being processed'.tr);
      return;
    }
    if (sc.drafts.isEmpty) return;
    final progress = 0.obs;
    final total = sc.drafts.length;
    final edits = sc.drafts.toList();

    int? docId = sc.targetDocId;
    String title = '';
    int? folderId;
    if (docId == null) {
      final tctrl = TextEditingController(text: '${'Scan'.tr} ${DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now())}');
      int? fId = dc.folderFilter.value;
      final ok = await Get.dialog<bool>(StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          title: Text('Save document'.tr),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: tctrl, decoration: InputDecoration(labelText: 'Title'.tr)),
            const SizedBox(height: 12),
            DropdownButtonFormField<int?>(
              value: fId,
              decoration: InputDecoration(labelText: 'Folder'.tr),
              items: [
                DropdownMenuItem<int?>(value: null, child: Text('No folder'.tr)),
                for (final f in dc.folders) DropdownMenuItem<int?>(value: f.id, child: Text(f.name)),
              ],
              onChanged: (v) => setState(() => fId = v),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Get.back(result: false), child: Text('Cancel'.tr)),
            FilledButton(onPressed: () => Get.back(result: true), child: Text('Save'.tr)),
          ],
        ),
      ));
      if (ok != true) return;
      title = tctrl.text.trim().isEmpty ? 'Scan'.tr : tctrl.text.trim();
      folderId = fId;
    }

    Get.dialog(
      PopScope(
        canPop: false,
        child: AlertDialog(
          title: Text('Saving…'.tr),
          content: Obx(() => Column(mainAxisSize: MainAxisSize.min, children: [
                LinearProgressIndicator(value: total == 0 ? null : progress.value / total),
                const SizedBox(height: 8),
                Text('${progress.value} / $total'),
              ])),
        ),
      ),
      barrierDismissible: false,
    );
    try {
      if (docId == null) {
        docId = await dc.createDoc(title, folderId, edits, progress: progress);
      } else {
        await dc.addToDoc(docId, edits, progress: progress);
      }
      Get.back();
      sc.clear();
      Get.until((r) => r.isFirst);
      Get.to(() => DocDetailView(docId: docId!));
    } catch (e) {
      if (Get.isDialogOpen == true) Get.back();
      toast('Error'.tr, 'Could not save the document'.tr, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final sc = Get.find<ScanController>();
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () async {
            if (sc.drafts.isEmpty || await confirm('Discard scan'.tr, 'Discard all captured pages?'.tr)) {
              sc.clear();
              Get.back();
            }
          },
        ),
        title: Obx(() => Text('Review (@n)'.trParams({'n': '${sc.drafts.length}'}))),
        actions: [
          PopupMenuButton<int>(
            icon: const Icon(Icons.auto_fix_high),
            tooltip: 'Apply filter to all pages'.tr,
            onSelected: sc.applyFilterToAll,
            itemBuilder: (_) => [
              for (var i = 0; i < kFilterNames.length; i++) PopupMenuItem(value: i, child: Text(kFilterNames[i].tr)),
            ],
          ),
        ],
      ),
      body: Column(children: [
        Obx(() => sc.pending.value > 0
            ? LinearProgressIndicator(minHeight: 3, semanticsLabel: 'Processing'.tr)
            : const SizedBox(height: 3)),
        Expanded(
          child: Obx(() {
            final list = sc.drafts.toList();
            if (list.isEmpty) return Center(child: Text(sc.pending.value > 0 ? 'Processing…'.tr : 'No pages'.tr));
            return ReorderableListView.builder(
              buildDefaultDragHandles: false,
              padding: const EdgeInsets.fromLTRB(8, 8, 8, 100),
              itemCount: list.length,
              onReorder: sc.reorder,
              itemBuilder: (_, i) {
                final e = list[i];
                return Card(
                  key: ValueKey(e.uid),
                  child: ListTile(
                    onTap: () async {
                      final r = await Get.to<PageEdit>(() => PageEditView(edit: e.copy()));
                      if (r != null) {
                        e.setFrom(r);
                        sc.rebuildThumb(e);
                      }
                    },
                    leading: SizedBox(
                      width: 60,
                      height: 78,
                      child: e.thumbPath == null || e.busy
                          ? const Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)))
                          : ClipRRect(borderRadius: BorderRadius.circular(4), child: Image.file(File(e.thumbPath!), key: ValueKey(e.thumbPath), fit: BoxFit.cover)),
                    ),
                    title: Text('Page @n'.trParams({'n': '${i + 1}'})),
                    subtitle: Text(kFilterNames[e.filter].tr),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => sc.remove(e)),
                      ReorderableDragStartListener(index: i, child: const Padding(padding: EdgeInsets.all(8), child: Icon(Icons.drag_handle))),
                    ]),
                  ),
                );
              },
            );
          }),
        ),
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
          child: Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                icon: const Icon(Icons.add_a_photo_outlined),
                label: Text('Add pages'.tr),
                onPressed: () => Get.to(() => const CameraView(fromReview: true)),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: FilledButton.icon(
                icon: const Icon(Icons.check),
                label: Text('Save'.tr),
                onPressed: _save,
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
