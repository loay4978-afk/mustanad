import 'package:get/get.dart';

import 'controllers/docs_controller.dart';
import 'controllers/scan_controller.dart';
import 'controllers/tools_controller.dart';

class InitialBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(DocsController(), permanent: true);
    Get.put(ScanController(), permanent: true);
    Get.put(ToolsController(), permanent: true);
  }
}
