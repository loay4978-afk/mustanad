import 'dart:convert';
import 'dart:math';
import 'dart:ui' as ui;

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../data/db/app_db.dart';
import '../views/widgets/paywall.dart';

/// الإعدادات العامة + الاشتراك (مجاني/Pro) + قفل التطبيق بـ PIN
class AppController extends GetxController {
  final _db = AppDb.instance;

  final lang = 'ar'.obs;
  final themeMode = ThemeMode.light.obs;
  final ocrLangs = <String>['ara', 'eng'].obs;
  final pdfQuality = 0.obs; // 0 عالية 1 متوسطة 2 منخفضة
  final pdfSize = 'fit'.obs; // fit | a4 | letter
  final autoCapture = true.obs;
  final autoOcr = true.obs;
  final isPro = false.obs;
  final hasPin = false.obs;
  final sessionUnlocked = false.obs;

  static const supported = ['ar', 'en', 'de'];

  Future<void> load() async {
    final l = await _db.getSetting('lang');
    final dev = ui.PlatformDispatcher.instance.locale.languageCode;
    lang.value = l ?? (supported.contains(dev) ? dev : 'ar');
    themeMode.value = (await _db.getSetting('theme')) == 'dark' ? ThemeMode.dark : ThemeMode.light;
    final ol = await _db.getSetting('ocr_langs');
    if (ol != null && ol.isNotEmpty) ocrLangs.assignAll(ol.split(','));
    pdfQuality.value = int.tryParse(await _db.getSetting('pdf_quality') ?? '') ?? 0;
    pdfSize.value = (await _db.getSetting('pdf_size')) ?? 'fit';
    autoCapture.value = (await _db.getSetting('auto_capture')) != '0';
    autoOcr.value = (await _db.getSetting('auto_ocr')) != '0';
    isPro.value = (await _db.getSetting('pro')) == '1';
    hasPin.value = (await _db.getSetting('pin_hash')) != null;
  }

  Future<void> setLang(String c) async {
    lang.value = c;
    await _db.setSetting('lang', c);
    Get.updateLocale(Locale(c));
  }

  Future<void> setDark(bool v) async {
    themeMode.value = v ? ThemeMode.dark : ThemeMode.light;
    Get.changeThemeMode(themeMode.value);
    await _db.setSetting('theme', v ? 'dark' : 'light');
  }

  Future<void> setOcrLangs(List<String> l) async {
    ocrLangs.assignAll(l.isEmpty ? ['eng'] : l);
    await _db.setSetting('ocr_langs', ocrLangs.join(','));
  }

  Future<void> setPdfQuality(int v) async {
    pdfQuality.value = v;
    await _db.setSetting('pdf_quality', '$v');
  }

  Future<void> setPdfSize(String v) async {
    pdfSize.value = v;
    await _db.setSetting('pdf_size', v);
  }

  Future<void> setAutoCapture(bool v) async {
    autoCapture.value = v;
    await _db.setSetting('auto_capture', v ? '1' : '0');
  }

  Future<void> setAutoOcr(bool v) async {
    autoOcr.value = v;
    await _db.setSetting('auto_ocr', v ? '1' : '0');
  }

  // ───────── النسخة المدفوعة ─────────
  Future<void> setPro(bool v) async {
    isPro.value = v;
    await _db.setSetting('pro', v ? '1' : '0');
  }

  /// يرجع true إذا كانت الميزة متاحة (Pro)، وإلا يعرض شاشة الاشتراك
  Future<bool> requirePro(String feature) async {
    if (isPro.value) return true;
    await showPaywall(feature);
    return isPro.value;
  }

  // ───────── قفل PIN ─────────
  String _hash(String salt, String pin) => sha256.convert(utf8.encode('$salt:$pin')).toString();

  Future<void> setPin(String pin) async {
    final salt = List.generate(12, (_) => Random.secure().nextInt(36).toRadixString(36)).join();
    await _db.setSetting('pin_salt', salt);
    await _db.setSetting('pin_hash', _hash(salt, pin));
    hasPin.value = true;
  }

  Future<void> clearPin() async {
    final d = await _db.database;
    await d.delete('settings', where: 'key IN (?, ?)', whereArgs: ['pin_salt', 'pin_hash']);
    hasPin.value = false;
  }

  Future<bool> verifyPin(String pin) async {
    final salt = await _db.getSetting('pin_salt');
    final h = await _db.getSetting('pin_hash');
    if (salt == null || h == null) return true;
    return _hash(salt, pin) == h;
  }
}
