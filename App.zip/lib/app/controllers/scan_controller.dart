import 'dart:typed_data';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../core/pdf_service.dart';
import '../core/storage.dart';
import '../data/models/models.dart';
import '../engine/scanner_engine.dart';

/// جلسة المسح: مسودات الصفحات قبل الحفظ كمستند
class ScanController extends GetxController {
  final drafts = <PageEdit>[].obs;
  final pending = 0.obs; // عدد الصور قيد المعالجة
  int _uid = 0;
  int? targetDocId; // إذا كانت الجلسة لإضافة صفحات إلى مستند موجود

  Future<void> addFile(String path, {bool detect = true, Uint8List? bytes, bool fullFrame = false, int filter = 1}) async {
    pending.value++;
    try {
      final out = await Storage.newPath('drafts', 'jpg');
      final r = await compute<Map<String, Object?>, Map<String, Object?>>(normalizeAndDetect, {
        'src': path,
        'bytes': bytes,
        'out': out,
        'detect': detect,
      });
      final e = PageEdit(
        uid: ++_uid,
        origPath: out,
        origW: r['w'] as int,
        origH: r['h'] as int,
        corners: fullFrame ? [0, 0, 1, 0, 1, 1, 0, 1] : (r['corners'] as List).cast<double>(),
        filter: filter,
      );
      drafts.add(e);
      await rebuildThumb(e);
    } catch (_) {
      // صورة تالفة: نتجاهلها
    } finally {
      pending.value--;
    }
  }

  Future<void> rebuildThumb(PageEdit e) async {
    e.busy = true;
    drafts.refresh();
    try {
      final r = await compute<Map<String, Object?>, Map<String, Object?>>(processEntry, {
        'path': e.origPath,
        'corners': e.corners,
        'filter': e.filter,
        'rotation': e.rotation,
        'brightness': e.brightness,
        'contrast': e.contrast,
        'maxSide': 480,
        'quality': 70,
      });
      final tp = await Storage.newPath('drafts', 'jpg');
      await File(tp).writeAsBytes(r['bytes'] as Uint8List);
      Storage.deleteQuiet(e.thumbPath);
      e.thumbPath = tp;
    } finally {
      e.busy = false;
      drafts.refresh();
    }
  }

  Future<void> addFiles(List<String> paths, {bool detect = true}) async {
    for (final p in paths) {
      await addFile(p, detect: detect);
    }
  }

  Future<int> pickFromGallery() async {
    final files = await ImagePicker().pickMultiImage();
    if (files.isEmpty) return 0;
    await addFiles(files.map((f) => f.path).toList());
    return files.length;
  }

  /// يحوّل صفحات PDF إلى مسودات (للاستيراد والدمج)
  Future<void> addPdf(String pdfPath) async {
    pending.value++;
    try {
      await for (final png in PdfService.rasterize(pdfPath)) {
        await addFile('', bytes: png, detect: false, fullFrame: true, filter: 0);
      }
    } finally {
      pending.value--;
    }
  }

  void remove(PageEdit e) {
    drafts.remove(e);
    Storage.deleteQuiet(e.thumbPath);
    Storage.deleteQuiet(e.origPath);
  }

  void reorder(int oldIndex, int newIndex) {
    if (newIndex > oldIndex) newIndex--;
    final e = drafts.removeAt(oldIndex);
    drafts.insert(newIndex, e);
  }

  Future<void> applyFilterToAll(int filter) async {
    for (final e in drafts) {
      e.filter = filter;
    }
    for (final e in drafts.toList()) {
      await rebuildThumb(e);
    }
  }

  void clear() {
    for (final e in drafts) {
      Storage.deleteQuiet(e.thumbPath);
      Storage.deleteQuiet(e.origPath);
    }
    drafts.clear();
    targetDocId = null;
  }
}
