import 'dart:io';

import 'package:archive/archive.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:path/path.dart' as p;

import '../core/pdf_service.dart';
import '../core/storage.dart';
import '../data/db/app_db.dart';
import '../engine/scanner_engine.dart';
import 'app_controller.dart';
import 'docs_controller.dart';

Future<String> _zipEntry(Map<String, Object?> a) async {
  final dir = Directory(a['dir'] as String);
  final archive = Archive();
  for (final f in dir.listSync(recursive: true)) {
    if (f is! File) continue;
    final rel = p.relative(f.path, from: dir.path).replaceAll('\\', '/');
    if (rel.startsWith('drafts/') || rel.startsWith('tmp/')) continue;
    final bytes = f.readAsBytesSync();
    archive.addFile(ArchiveFile(rel, bytes.length, bytes));
  }
  final data = ZipEncoder().encode(archive)!;
  File(a['out'] as String).writeAsBytesSync(data);
  return a['out'] as String;
}

Future<int> _unzipEntry(Map<String, Object?> a) async {
  final bytes = File(a['zip'] as String).readAsBytesSync();
  final archive = ZipDecoder().decodeBytes(bytes);
  final root = a['dir'] as String;
  var n = 0;
  for (final f in archive) {
    if (!f.isFile) continue;
    if (f.name.contains('..')) continue; // حماية من مسارات خبيثة
    final out = File(p.join(root, f.name));
    out.parent.createSync(recursive: true);
    out.writeAsBytesSync(f.content as List<int>);
    n++;
  }
  return n;
}

class ToolsController extends GetxController {
  /// يحوّل PDF خارجي إلى ملفات JPG مؤقتة: يرجع (مسارات، أبعاد)
  Future<({List<String> paths, List<int> dims})> rasterizeToTemp(String pdfPath, {RxInt? progress}) async {
    final paths = <String>[];
    final dims = <int>[];
    var i = 0;
    await for (final png in PdfService.rasterize(pdfPath, dpi: 150)) {
      final out = await Storage.newPath('tmp', 'jpg');
      final r = await compute<Map<String, Object?>, Map<String, Object?>>(normalizeAndDetect, {
        'bytes': png,
        'out': out,
        'detect': false,
      });
      paths.add(out);
      dims.addAll([r['w'] as int, r['h'] as int]);
      progress?.value = ++i;
    }
    return (paths: paths, dims: dims);
  }

  /// ضغط PDF خارجي: تحويل الصفحات إلى صور ثم إعادة بنائه بجودة أقل
  Future<File> compressPdf(String pdfPath, String title, int quality, {RxInt? progress}) async {
    final r = await rasterizeToTemp(pdfPath, progress: progress);
    final f = await PdfService.build(title, r.paths, r.dims,
        PdfOptions(quality: quality, size: 'fit', watermark: !Get.find<AppController>().isPro.value));
    for (final x in r.paths) {
      Storage.deleteQuiet(x);
    }
    return f;
  }

  /// تقسيم PDF خارجي: استخراج صفحات محددة في ملف جديد
  Future<File?> splitPdf(String pdfPath, String title, String ranges, {RxInt? progress}) async {
    final r = await rasterizeToTemp(pdfPath, progress: progress);
    final sel = parseRangesLocal(ranges, r.paths.length);
    if (sel.isEmpty) {
      for (final x in r.paths) {
        Storage.deleteQuiet(x);
      }
      return null;
    }
    final f = await PdfService.build(
      title,
      [for (final i in sel) r.paths[i - 1]],
      [for (final i in sel) ...[r.dims[2 * (i - 1)], r.dims[2 * (i - 1) + 1]]],
      PdfOptions(quality: 0, size: 'fit', watermark: !Get.find<AppController>().isPro.value),
    );
    for (final x in r.paths) {
      Storage.deleteQuiet(x);
    }
    return f;
  }

  List<int> parseRangesLocal(String s, int max) {
    final out = <int>[];
    for (final part in s.split(RegExp(r'[,،;\s]+'))) {
      if (part.isEmpty) continue;
      final m = RegExp(r'^(\d+)\s*-\s*(\d+)$').firstMatch(part);
      if (m != null) {
        final a = int.parse(m.group(1)!), b = int.parse(m.group(2)!);
        for (var i = a < b ? a : b; i <= (a < b ? b : a); i++) {
          if (i >= 1 && i <= max && !out.contains(i)) out.add(i);
        }
      } else {
        final n = int.tryParse(part);
        if (n != null && n >= 1 && n <= max && !out.contains(n)) out.add(n);
      }
    }
    return out;
  }

  // ───────── النسخ الاحتياطي ─────────
  Future<File> backup() async {
    final base = await Storage.base();
    final stamp = DateTime.now().toIso8601String().substring(0, 19).replaceAll(RegExp(r'[:T]'), '-');
    final out = await Storage.tempFile('mustanad_backup_$stamp.zip');
    await compute<Map<String, Object?>, String>(_zipEntry, {'dir': base.path, 'out': out.path});
    return out;
  }

  Future<int> restore(String zipPath) async {
    final base = await Storage.base();
    await AppDb.instance.close();
    for (final e in base.listSync()) {
      try {
        e.deleteSync(recursive: true);
      } catch (_) {}
    }
    final n = await compute<Map<String, Object?>, int>(_unzipEntry, {'zip': zipPath, 'dir': base.path});
    await Get.find<AppController>().load();
    await Get.find<DocsController>().load();
    return n;
  }
}
