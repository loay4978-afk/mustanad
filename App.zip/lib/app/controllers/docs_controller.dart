import 'dart:typed_data';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';

import '../core/ocr_service.dart';
import '../core/pdf_service.dart';
import '../core/storage.dart';
import '../core/text_normalize.dart';
import '../core/utils.dart';
import '../data/db/app_db.dart';
import '../data/models/models.dart';
import '../engine/scanner_engine.dart';
import 'app_controller.dart';

class DocsController extends GetxController {
  final _db = AppDb.instance;

  final folders = <FolderModel>[].obs;
  final docs = <DocModel>[].obs;
  final folderFilter = RxnInt();
  final query = ''.obs;
  final tagFilter = ''.obs;
  final sort = 'date'.obs; // date | name
  final favOnly = false.obs;
  final grid = false.obs;
  final ocrRunning = <int>{}.obs;
  final unlocked = <int>{}; // مستندات مقفلة تم فتحها في هذه الجلسة
  final Map<String, String> _hayCache = {};

  AppController get _app => Get.find<AppController>();

  @override
  void onInit() {
    super.onInit();
    load();
  }

  Future<void> load() async {
    folders.assignAll(await _db.getFolders());
    docs.assignAll(await _db.getDocs());
  }

  List<String> get allTags {
    final s = <String>{};
    for (final d in docs) {
      s.addAll(d.tags);
    }
    return s.toList()..sort();
  }

  String _hay(DocModel d) => _hayCache.putIfAbsent(
        '${d.id}_${d.updatedAt.millisecondsSinceEpoch}_${d.ocrText.length}_${d.locked}',
        () => normalizeText('${d.title} ${d.tags.join(' ')} ${d.locked ? '' : d.ocrText}'),
      );

  List<DocModel> get visible {
    var l = docs.toList();
    if (folderFilter.value != null) l = l.where((d) => d.folderId == folderFilter.value).toList();
    if (favOnly.value) l = l.where((d) => d.favorite).toList();
    if (tagFilter.value.isNotEmpty) l = l.where((d) => d.tags.contains(tagFilter.value)).toList();
    final q = query.value.trim();
    if (q.isNotEmpty) l = l.where((d) => matchesAll(_hay(d), q)).toList();
    if (sort.value == 'name') {
      l.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    } else {
      l.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    }
    return l;
  }

  String snippetFor(DocModel d) {
    final q = query.value.trim();
    if (q.isEmpty || d.locked) return '';
    return snippetAround(d.ocrText, q);
  }

  // ───────── المجلدات ─────────
  Future<void> createFolder(String name) async {
    await _db.insertFolder(name, 0xFF1565C0);
    await load();
  }

  Future<void> renameFolder(FolderModel f, String name) async {
    await _db.renameFolder(f.id!, name);
    await load();
  }

  Future<void> deleteFolder(FolderModel f) async {
    await _db.deleteFolder(f.id!);
    if (folderFilter.value == f.id) folderFilter.value = null;
    await load();
  }

  // ───────── المستندات والصفحات ─────────
  Future<List<PageModel>> pages(int docId) => _db.getPages(docId);

  Future<Map<String, Object?>> _render(PageEdit e, {int maxSide = 2600, int quality = 90}) async {
    return compute<Map<String, Object?>, Map<String, Object?>>(processEntry, {
      'path': e.origPath,
      'corners': e.corners,
      'filter': e.filter,
      'rotation': e.rotation,
      'brightness': e.brightness,
      'contrast': e.contrast,
      'maxSide': maxSide,
      'quality': quality,
    });
  }

  Future<void> _appendPages(int docId, int start, List<PageEdit> edits, RxInt? progress) async {
    for (var i = 0; i < edits.length; i++) {
      final e = edits[i];
      final r = await _render(e);
      final proc = await Storage.newPath('pages', 'jpg');
      await File(proc).writeAsBytes(r['bytes'] as Uint8List);
      final orig = await Storage.newPath('pages', 'jpg');
      await File(e.origPath).copy(orig);
      await _db.insertPage(
        docId,
        start + i,
        origPath: orig,
        procPath: proc,
        origW: e.origW,
        origH: e.origH,
        corners: e.corners,
        filter: e.filter,
        rotation: e.rotation,
        brightness: e.brightness,
        contrast: e.contrast,
        width: r['w'] as int,
        height: r['h'] as int,
      );
      progress?.value = i + 1;
    }
  }

  Future<int> createDoc(String title, int? folderId, List<PageEdit> edits, {RxInt? progress}) async {
    final id = await _db.insertDoc(title, folderId);
    await _appendPages(id, 0, edits, progress);
    await load();
    if (_app.autoOcr.value) runOcr(id);
    return id;
  }

  Future<void> addToDoc(int docId, List<PageEdit> edits, {RxInt? progress}) async {
    final start = (await _db.getPages(docId)).length;
    await _appendPages(docId, start, edits, progress);
    await _db.updateDoc(docId, {});
    await load();
    if (_app.autoOcr.value) runOcr(docId);
  }

  Future<void> updatePageFromEdit(PageModel p, PageEdit e) async {
    final r = await _render(e);
    final proc = await Storage.newPath('pages', 'jpg');
    await File(proc).writeAsBytes(r['bytes'] as Uint8List);
    Storage.deleteQuiet(p.procPath);
    Storage.deleteQuiet(p.finalPath);
    await _db.updatePage(p.id, {
      'proc_path': proc,
      'final_path': null,
      'annotations': '[]',
      'ocr_text': '',
      'corners': '[${e.corners.join(',')}]',
      'filter': e.filter,
      'rotation': e.rotation,
      'brightness': e.brightness,
      'contrast': e.contrast,
      'width': r['w'],
      'height': r['h'],
    });
    await _db.updateDoc(p.docId, {});
    await load();
    if (_app.autoOcr.value) runOcr(p.docId);
  }

  /// يحفظ نتيجة التعليقات (JPEG مدموج) أو يلغيها إذا كانت القائمة فارغة
  Future<void> saveAnnotated(PageModel p, String annotationsJson, Uint8List? jpeg) async {
    String? path;
    if (jpeg != null) {
      path = await Storage.newPath('pages', 'jpg');
      await File(path).writeAsBytes(jpeg);
    }
    Storage.deleteQuiet(p.finalPath);
    await _db.updatePage(p.id, {'final_path': path, 'annotations': annotationsJson});
    await _db.updateDoc(p.docId, {});
    await load();
  }

  Future<void> renameDoc(DocModel d, String title) async {
    await _db.updateDoc(d.id, {'title': title});
    await load();
  }

  Future<void> setTags(DocModel d, List<String> tags) async {
    await _db.updateDoc(d.id, {'tags': tags.join(',')}, touch: false);
    await load();
  }

  Future<void> toggleFavorite(DocModel d) async {
    await _db.updateDoc(d.id, {'favorite': d.favorite ? 0 : 1}, touch: false);
    await load();
  }

  Future<void> setLocked(DocModel d, bool v) async {
    await _db.updateDoc(d.id, {'locked': v ? 1 : 0}, touch: false);
    if (v) unlocked.remove(d.id);
    await load();
  }

  Future<void> moveToFolder(DocModel d, int? folderId) async {
    await _db.updateDoc(d.id, {'folder_id': folderId}, touch: false);
    await load();
  }

  Future<void> deleteDoc(int id) async {
    final files = await _db.deleteDoc(id);
    for (final f in files) {
      Storage.deleteQuiet(f);
    }
    await load();
  }

  Future<void> reorder(int docId, List<PageModel> ordered) async {
    await _db.setPositions(ordered.map((p) => p.id).toList());
    await _db.updateDoc(docId, {});
    await load();
  }

  Future<void> _refreshDocOcr(int docId) async {
    final pages = await _db.getPages(docId);
    final all = pages.map((p) => p.ocrText).where((t) => t.isNotEmpty).join('\n\n');
    await _db.updateDoc(docId, {'ocr_text': all}, touch: false);
  }

  Future<void> deletePages(List<PageModel> pages) async {
    if (pages.isEmpty) return;
    final docId = pages.first.docId;
    for (final p in pages) {
      await _db.deletePage(p.id);
      Storage.deleteQuiet(p.origPath);
      Storage.deleteQuiet(p.procPath);
      Storage.deleteQuiet(p.finalPath);
    }
    final rest = await _db.getPages(docId);
    if (rest.isEmpty) {
      await deleteDoc(docId);
      return;
    }
    await _db.setPositions(rest.map((p) => p.id).toList());
    await _refreshDocOcr(docId);
    await _db.updateDoc(docId, {});
    await load();
  }

  /// تقسيم: ينقل الصفحات المحددة إلى مستند جديد
  Future<int?> extractPages(List<PageModel> pages, String title, int? folderId) async {
    if (pages.isEmpty) return null;
    final src = pages.first.docId;
    final newId = await _db.insertDoc(title, folderId);
    for (var i = 0; i < pages.length; i++) {
      await _db.movePage(pages[i].id, newId, i);
    }
    final rest = await _db.getPages(src);
    if (rest.isEmpty) {
      await _db.deleteDoc(src);
    } else {
      await _db.setPositions(rest.map((p) => p.id).toList());
      await _refreshDocOcr(src);
    }
    await _refreshDocOcr(newId);
    await load();
    return newId;
  }

  Future<String> _copyFile(String path) async {
    final dot = path.lastIndexOf('.');
    final ext = dot >= 0 ? path.substring(dot + 1) : 'jpg';
    final np = await Storage.newPath('pages', ext);
    await File(path).copy(np);
    return np;
  }

  /// دمج عدة مستندات في مستند جديد (تُنسخ الصفحات)
  Future<int> mergeDocs(List<int> ids, String title, int? folderId) async {
    final newId = await _db.insertDoc(title, folderId);
    var pos = 0;
    for (final id in ids) {
      for (final p in await _db.getPages(id)) {
        final pid = await _db.insertPage(
          newId,
          pos++,
          origPath: await _copyFile(p.origPath),
          procPath: await _copyFile(p.procPath),
          origW: p.origW,
          origH: p.origH,
          corners: p.corners,
          filter: p.filter,
          rotation: p.rotation,
          brightness: p.brightness,
          contrast: p.contrast,
          width: p.width,
          height: p.height,
          ocrText: p.ocrText,
        );
        if (p.finalPath != null) {
          await _db.updatePage(pid, {'final_path': await _copyFile(p.finalPath!), 'annotations': p.annotations});
        }
      }
    }
    await _refreshDocOcr(newId);
    await load();
    return newId;
  }

  // ───────── OCR ─────────
  Future<void> runOcr(int docId, {bool force = false}) async {
    if (ocrRunning.contains(docId)) return;
    ocrRunning.add(docId);
    try {
      final langs = _app.ocrLangs.toList();
      for (final p in await _db.getPages(docId)) {
        if (!force && p.ocrText.isNotEmpty) continue;
        final t = await OcrService.recognize(p.displayPath, langs);
        await _db.updatePage(p.id, {'ocr_text': t});
      }
      await _refreshDocOcr(docId);
      await load();
    } catch (e) {
      toast('OCR', 'OCR failed'.tr, error: true);
    } finally {
      ocrRunning.remove(docId);
    }
  }

  // ───────── التصدير ─────────
  Future<File> exportPdf(DocModel d, List<PageModel> pages, PdfOptions o) {
    final opts = PdfOptions(quality: o.quality, size: o.size, watermark: !_app.isPro.value);
    return PdfService.build(
      d.title,
      pages.map((p) => p.displayPath).toList(),
      [for (final p in pages) ...[p.width, p.height]],
      opts,
    );
  }

  Future<void> shareFile(File f, {String? text}) async {
    await Share.shareXFiles([XFile(f.path)], text: text);
  }
}
