import 'text_normalize.dart';

class InvoiceData {
  String? vendor, invoiceNo, date, currency, subtotal, tax, taxRate, total, email, phone, taxId;
  List<String> items = [];

  Map<String, String> toMap() => {
        if (vendor != null) 'vendor': vendor!,
        if (invoiceNo != null) 'invoice_no': invoiceNo!,
        if (date != null) 'date': date!,
        if (currency != null) 'currency': currency!,
        if (subtotal != null) 'subtotal': subtotal!,
        if (tax != null) 'tax': tax!,
        if (taxRate != null) 'tax_rate': taxRate!,
        if (total != null) 'total': total!,
        if (taxId != null) 'tax_id': taxId!,
        if (email != null) 'email': email!,
        if (phone != null) 'phone': phone!,
      };

  bool get isEmpty => toMap().isEmpty && items.isEmpty;
}

List<String> _k(List<String> l) => l.map(normalizeText).toList();
final _totalKw = _k(['total', 'grand total', 'amount due', 'balance due', 'الاجمالي', 'اجمالي', 'المجموع', 'الصافي', 'المبلغ المستحق', 'gesamt', 'summe', 'endbetrag', 'zu zahlen', 'betrag']);
final _subKw = _k(['subtotal', 'sub total', 'sub-total', 'المجموع الفرعي', 'قبل الضريبه', 'zwischensumme', 'netto']);
final _taxKw = _k(['vat', 'tax', 'ضريبه', 'mwst', 'ust', 'steuer']);
final _dateKw = _k(['date', 'تاريخ', 'datum']);

double? _parseNum(String raw) {
  var s = raw.replaceAll(RegExp(r'[.,]+$'), '');
  if (s.isEmpty) return null;
  final lastDot = s.lastIndexOf('.'), lastComma = s.lastIndexOf(',');
  if (lastDot >= 0 && lastComma >= 0) {
    if (lastDot > lastComma) {
      s = s.replaceAll(',', '');
    } else {
      s = s.replaceAll('.', '').replaceAll(',', '.');
    }
  } else if (lastComma >= 0) {
    s = RegExp(r',\d{1,2}$').hasMatch(s) ? s.replaceAll(',', '.') : s.replaceAll(',', '');
  } else if (lastDot >= 0) {
    if (RegExp(r'^\d{1,3}(\.\d{3})+$').hasMatch(s)) s = s.replaceAll('.', '');
  }
  return double.tryParse(s);
}

List<double> _amounts(String line) {
  final out = <double>[];
  for (final m in RegExp(r'\d[\d.,]*').allMatches(line)) {
    final v = _parseNum(m.group(0)!);
    if (v != null) out.add(v);
  }
  return out;
}

String _fmt(double v) => v == v.roundToDouble() ? v.toStringAsFixed(2) : v.toStringAsFixed(2);

InvoiceData parseInvoice(String raw) {
  final d = InvoiceData();
  final orig = raw.split('\n').map((l) => l.trim()).where((l) => l.isNotEmpty).toList();
  final lines = orig.map(normalizeText).toList();
  if (lines.isEmpty) return d;
  final all = lines.join('\n');

  // العملة
  const cur = {
    'SAR': r'sar|ر\.?\s?س|ريال',
    'AED': r'aed|درهم',
    'EGP': r'egp|جنيه|ج\.?\s?م',
    'KWD': r'kwd|د\.?\s?ك|دينار',
    'USD': r'usd|\$',
    'EUR': r'eur|€',
    'GBP': r'gbp|£',
    'TRY': r'try|₺|\btl\b',
  };
  for (final e in cur.entries) {
    if (RegExp(e.value, caseSensitive: false).hasMatch(all)) {
      d.currency = e.key;
      break;
    }
  }

  // التاريخ
  final dre1 = RegExp(r'(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})');
  final dre2 = RegExp(r'(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})');
  String? findDate(String l) => dre2.firstMatch(l)?.group(0) ?? dre1.firstMatch(l)?.group(0);
  for (final l in lines) {
    if (_dateKw.any(l.contains)) {
      final f = findDate(l);
      if (f != null) {
        d.date = f;
        break;
      }
    }
  }
  d.date ??= findDate(all);

  // رقم الفاتورة
  final noRe = RegExp(
      r'(?:invoice|inv|receipt|bill|rechnung|beleg|فاتوره|رقم)\s*(?:no|nr|number|num|#|:|\.|-)*\s*[:#\-]?\s*([a-z0-9][a-z0-9\-/]{2,})',
      caseSensitive: false);
  for (final l in lines) {
    for (final m in noRe.allMatches(l)) {
      final v = m.group(1)!;
      if (RegExp(r'\d').hasMatch(v)) {
        d.invoiceNo = v.toUpperCase();
        break;
      }
    }
    if (d.invoiceNo != null) break;
  }

  // المبالغ
  double? total, sub, tax;
  for (var i = 0; i < lines.length; i++) {
    final l = lines[i];
    final next = i + 1 < lines.length ? lines[i + 1] : '';
    List<double> amts() {
      final a = _amounts(l);
      return a.isNotEmpty ? a : _amounts(next);
    }

    final isSub = _subKw.any(l.contains);
    final isTax = _taxKw.any(l.contains);
    if (isSub) {
      final a = amts();
      if (a.isNotEmpty) sub = a.reduce((x, y) => x > y ? x : y);
    } else if (_totalKw.any(l.contains) && !isTax) {
      final a = amts();
      if (a.isNotEmpty) {
        final m = a.reduce((x, y) => x > y ? x : y);
        if (total == null || m > total) total = m;
      }
    } else if (isTax) {
      final pct = RegExp(r'(\d{1,2}(?:[.,]\d+)?)\s*%').firstMatch(l);
      if (pct != null) d.taxRate ??= '${pct.group(1)}%';
      final a = _amounts(l).where((x) => x > 0).toList();
      if (a.isNotEmpty && tax == null) tax = a.last;
    }
  }
  if (total == null) {
    var mx = 0.0;
    for (final l in lines) {
      for (final a in _amounts(l)) {
        if (a > mx && a < 100000000) mx = a;
      }
    }
    if (mx > 0) total = mx;
  }
  if (total != null) d.total = _fmt(total);
  if (sub != null) d.subtotal = _fmt(sub);
  if (tax != null) d.tax = _fmt(tax);

  // المورّد
  for (final l in orig.take(6)) {
    final n = normalizeText(l);
    if (RegExp(r'\p{L}{3,}', unicode: true).hasMatch(l) &&
        !RegExp(r'invoice|فاتوره|receipt|rechnung|tax|vat|date|تاريخ', caseSensitive: false).hasMatch(n) &&
        RegExp(r'\d').allMatches(l).length < l.length / 2) {
      d.vendor = l;
      break;
    }
  }

  d.email = RegExp(r'[\w.+-]+@[\w-]+\.[\w.-]+').firstMatch(all)?.group(0);
  d.phone = RegExp(r'\+?\d[\d\s().-]{7,}\d').allMatches(all).map((m) => m.group(0)!).firstWhere(
        (s) => s.replaceAll(RegExp(r'\D'), '').length >= 8 && s.replaceAll(RegExp(r'\D'), '').length <= 15 && !dre1.hasMatch(s) && !dre2.hasMatch(s),
        orElse: () => '',
      );
  if (d.phone!.isEmpty) d.phone = null;
  d.taxId = RegExp(r'(?:vat|trn|ust-?id(?:nr)?|الرقم الضريبي|الرقم الضريبى|الرقم الضريبي)[^a-z0-9]*([a-z0-9]{8,20})', caseSensitive: false)
      .firstMatch(all)
      ?.group(1)
      ?.toUpperCase();

  // بنود الفاتورة (تقريبي)
  for (var i = 0; i < orig.length && d.items.length < 25; i++) {
    final l = lines[i];
    if (_totalKw.any(l.contains) || _subKw.any(l.contains) || _taxKw.any(l.contains)) continue;
    if (RegExp(r'\p{L}{2,}', unicode: true).hasMatch(orig[i]) && RegExp(r'\d+[.,]\d{2}\s*\S{0,4}$').hasMatch(orig[i])) {
      d.items.add(orig[i]);
    }
  }
  return d;
}
