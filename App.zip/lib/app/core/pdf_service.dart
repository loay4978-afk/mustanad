import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../engine/scanner_engine.dart';
import 'storage.dart';

class PdfOptions {
  final int quality; // 0 عالية، 1 متوسطة، 2 منخفضة
  final String size; // fit | a4 | letter
  final bool watermark;
  const PdfOptions({this.quality = 0, this.size = 'fit', this.watermark = false});
}

/// يبني ملف PDF داخل Isolate
Future<Uint8List> _buildPdfEntry(Map<String, Object?> a) async {
  final paths = (a['paths'] as List).cast<String>();
  final dims = (a['dims'] as List).cast<int>(); // w,h,w,h...
  final quality = a['quality'] as int;
  final size = a['size'] as String;
  final watermark = a['watermark'] as bool;
  final doc = pw.Document(compress: true);

  pw.Widget wm() => pw.Positioned(
        right: 10,
        bottom: 8,
        child: pw.Text('Scanned with Mustanad', style: pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
      );

  for (var i = 0; i < paths.length; i++) {
    Uint8List bytes;
    var iw = dims[2 * i], ih = dims[2 * i + 1];
    if (quality == 0) {
      bytes = File(paths[i]).readAsBytesSync();
    } else {
      final r = recompressEntry({
        'path': paths[i],
        'maxSide': quality == 1 ? 1654 : 1240,
        'quality': quality == 1 ? 75 : 55,
      });
      bytes = r['bytes'] as Uint8List;
      iw = r['w'] as int;
      ih = r['h'] as int;
    }
    final image = pw.MemoryImage(bytes);
    if (size == 'fit') {
      const pageW = 595.28;
      final pageH = pageW * ih / iw;
      doc.addPage(pw.Page(
        pageFormat: PdfPageFormat(pageW, pageH),
        margin: pw.EdgeInsets.zero,
        build: (c) => pw.Stack(children: [
          pw.SizedBox.expand(child: pw.Image(image, fit: pw.BoxFit.fill)),
          if (watermark) wm(),
        ]),
      ));
    } else {
      final fmt = size == 'letter' ? PdfPageFormat.letter : PdfPageFormat.a4;
      doc.addPage(pw.Page(
        pageFormat: iw > ih ? fmt.landscape : fmt,
        margin: const pw.EdgeInsets.all(18),
        build: (c) => pw.Stack(children: [
          pw.Center(child: pw.Image(image, fit: pw.BoxFit.contain)),
          if (watermark) wm(),
        ]),
      ));
    }
  }
  return doc.save();
}

class PdfService {
  PdfService._();

  static String safeName(String s) {
    final n = s.replaceAll(RegExp(r'[\\/:*?"<>|\n\r]'), '_').trim();
    return n.isEmpty ? 'document' : n;
  }

  /// يبني PDF من مسارات الصور ويحفظه في ملف مؤقت جاهز للمشاركة
  static Future<File> build(String title, List<String> paths, List<int> dims, PdfOptions o) async {
    final bytes = await compute(_buildPdfEntry, <String, Object?>{
      'paths': paths,
      'dims': dims,
      'quality': o.quality,
      'size': o.size,
      'watermark': o.watermark,
    });
    final f = await Storage.tempFile('${safeName(title)}.pdf');
    await f.writeAsBytes(bytes, flush: true);
    return f;
  }

  /// يحوّل صفحات ملف PDF خارجي إلى صور PNG (للاستيراد/الدمج/التقسيم/الضغط)
  static Stream<Uint8List> rasterize(String pdfPath, {double dpi = 150}) async* {
    final bytes = await File(pdfPath).readAsBytes();
    await for (final page in Printing.raster(bytes, dpi: dpi)) {
      yield await page.toPng();
    }
  }
}
