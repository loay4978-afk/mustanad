import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:mustanad/app/core/invoice_parser.dart';
import 'package:mustanad/app/core/text_normalize.dart';
import 'package:mustanad/app/core/utils.dart';
import 'package:mustanad/app/engine/scanner_engine.dart';

void main() {
  test('detectQuad finds a bright rectangle on a dark background', () {
    const w = 160, h = 120;
    final g = Uint8List(w * h)..fillRange(0, w * h, 40);
    for (var y = 20; y < 100; y++) {
      for (var x = 30; x < 130; x++) {
        g[y * w + x] = 210;
      }
    }
    final r = detectQuad(GrayImage(w, h, g));
    expect(r, isNotNull);
    final c = r!.corners;
    expect((c[0].x - 30 / w).abs(), lessThan(0.05));
    expect((c[0].y - 20 / h).abs(), lessThan(0.05));
    expect((c[2].x - 130 / w).abs(), lessThan(0.05));
    expect((c[2].y - 100 / h).abs(), lessThan(0.05));
  });

  test('warpQuad on the full frame keeps the size', () {
    final src = RgbImage(40, 30, Uint8List(40 * 30 * 3)..fillRange(0, 40 * 30 * 3, 128));
    final out = warpQuad(src, const [Pt(0, 0), Pt(40, 0), Pt(40, 30), Pt(0, 30)]);
    expect(out.width, 40);
    expect(out.height, 30);
  });

  test('rotateQuarter swaps dimensions', () {
    final src = RgbImage(4, 2, Uint8List(4 * 2 * 3));
    final r = rotateQuarter(src, 1);
    expect(r.width, 2);
    expect(r.height, 4);
  });

  test('normalizeText folds Arabic and German variants', () {
    expect(normalizeText('الإجمالي'), normalizeText('الاجمالي'));
    expect(normalizeText('Straße'), 'strasse');
    expect(matchesAll(normalizeText('Rechnung Nr. 123'), 'rechnung 123'), true);
  });

  test('parseRanges', () {
    expect(parseRanges('1-3,5', 10), [1, 2, 3, 5]);
    expect(parseRanges('9-12', 10), [9, 10]);
  });

  test('parseInvoice extracts total, date and invoice number', () {
    const text = 'ACME Trading Co\nInvoice No: INV-2041\nDate: 12/03/2025\nSubtotal 100.00\nVAT 15% 15.00\nTotal 115.00 SAR';
    final d = parseInvoice(text);
    expect(d.total, '115.00');
    expect(d.invoiceNo, 'INV-2041');
    expect(d.date, '12/03/2025');
    expect(d.currency, 'SAR');
    expect(d.vendor, 'ACME Trading Co');
  });
}
